from pathlib import Path
import math
import os

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image, ImageDraw, ImageFont


BASE = Path(__file__).resolve().parent
DIAGRAMS = BASE / "diagrams"
DIAGRAMS.mkdir(parents=True, exist_ok=True)
OUT = BASE / "Automated_Payroll_Management_System_SRS.docx"
USP_LOGO = BASE / "extracted_pdf_images" / "page01_img01.jpg"


def pil_font(size=22, bold=False):
    paths = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibrib.ttf" if bold else r"C:\Windows\Fonts\calibri.ttf",
    ]
    for path in paths:
        if os.path.exists(path):
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


F_TITLE = pil_font(30, True)
F_HEAD = pil_font(22, True)
F_BODY = pil_font(18)
F_SMALL = pil_font(15)


def wrap(draw, text, width, font):
    lines = []
    for raw in str(text).split("\n"):
        words = raw.split()
        current = ""
        for word in words:
            trial = f"{current} {word}".strip()
            box = draw.textbbox((0, 0), trial, font=font)
            if box[2] - box[0] <= width:
                current = trial
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
    return lines or [""]


def centered_text(draw, rect, text, font=F_BODY, fill=(35, 35, 42)):
    x1, y1, x2, y2 = rect
    lines = wrap(draw, text, x2 - x1 - 20, font)
    heights = [draw.textbbox((0, 0), line, font=font)[3] for line in lines]
    y = y1 + ((y2 - y1) - sum(heights) - (len(lines) - 1) * 4) / 2
    for line, height in zip(lines, heights):
        box = draw.textbbox((0, 0), line, font=font)
        x = x1 + ((x2 - x1) - (box[2] - box[0])) / 2
        draw.text((x, y), line, font=font, fill=fill)
        y += height + 4


def draw_box(draw, rect, text, fill=(248, 250, 252), outline=(90, 111, 140), font=F_BODY):
    draw.rounded_rectangle(rect, radius=14, fill=fill, outline=outline, width=3)
    centered_text(draw, rect, text, font)


def draw_arrow(draw, start, end, fill=(65, 75, 90), width=3):
    draw.line([start, end], fill=fill, width=width)
    x1, y1 = start
    x2, y2 = end
    angle = math.atan2(y2 - y1, x2 - x1)
    length = 14
    points = [
        (x2, y2),
        (x2 - length * math.cos(angle - math.pi / 6), y2 - length * math.sin(angle - math.pi / 6)),
        (x2 - length * math.cos(angle + math.pi / 6), y2 - length * math.sin(angle + math.pi / 6)),
    ]
    draw.polygon(points, fill=fill)


def canvas(title):
    image = Image.new("RGB", (1200, 760), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, 1200, 72), fill=(232, 238, 245))
    draw.text((40, 18), title, font=F_TITLE, fill=(0, 0, 0))
    return image, draw


def save(image, name):
    path = DIAGRAMS / name
    image.save(path)
    return path


def make_diagrams():
    paths = []

    image, draw = canvas("Existing Manual Payroll Record Structure")
    boxes = [
        ((60, 135, 335, 285), "Employee File\nCode, name, salary,\ndepartment"),
        ((460, 135, 740, 285), "Attendance Sheet\nDate, status,\ntime in/out"),
        ((865, 135, 1145, 285), "Leave Register\nLeave type,\nduration, remarks"),
        ((260, 430, 545, 600), "Payroll Sheet\nBasic salary,\nallowance, net pay"),
        ((660, 430, 945, 600), "Accounts Ledger\nDebit, credit,\nbalance"),
    ]
    for rect, text in boxes:
        draw_box(draw, rect, text)
    for a, b in [((335, 210), (460, 210)), ((740, 210), (865, 210)), ((600, 285), (455, 430)), ((1000, 285), (800, 430)), ((545, 515), (660, 515))]:
        draw_arrow(draw, a, b)
    paths.append(save(image, "figure1_existing_erd.png"))

    image, draw = canvas("Existing Manual Payroll Sequence")
    xs = [150, 400, 650, 900]
    labels = ["HR/Admin", "Employee File", "Attendance Sheet", "Payroll Clerk"]
    for x, label in zip(xs, labels):
        draw_box(draw, (x - 90, 120, x + 90, 175), label, font=F_SMALL)
        draw.line((x, 175, x, 660), fill=(165, 165, 175), width=2)
    steps = [(150, 400, 230, "collect data"), (400, 650, 315, "copy attendance"), (650, 900, 400, "calculate salary"), (900, 150, 500, "prepare report")]
    for a, b, y, text in steps:
        draw_arrow(draw, (a, y), (b, y))
        draw.text((min(a, b) + 20, y - 25), text, font=F_SMALL, fill=(45, 55, 70))
    paths.append(save(image, "figure2_existing_sequence.png"))

    image, draw = canvas("Existing System Architecture")
    for rect, text in [
        ((80, 250, 310, 410), "Manual Forms\nand Registers"),
        ((480, 170, 720, 310), "Spreadsheet\nCalculation"),
        ((480, 430, 720, 570), "Paper Files\nand Payslips"),
        ((890, 285, 1130, 445), "Manual Accounts\nLedger"),
    ]:
        draw_box(draw, rect, text)
    for a, b in [((310, 330), (480, 240)), ((310, 330), (480, 500)), ((720, 240), (890, 330)), ((720, 500), (890, 400))]:
        draw_arrow(draw, a, b)
    paths.append(save(image, "figure3_existing_architecture.png"))

    image, draw = canvas("Existing System Use Case")
    draw.rounded_rectangle((250, 110, 1120, 650), radius=24, outline=(120, 135, 160), width=3)
    draw.ellipse((55, 200, 135, 280), outline=(65, 75, 90), width=3)
    draw.line((95, 280, 95, 420), fill=(65, 75, 90), width=3)
    draw.line((45, 330, 145, 330), fill=(65, 75, 90), width=3)
    draw.line((95, 420, 55, 510), fill=(65, 75, 90), width=3)
    draw.line((95, 420, 135, 510), fill=(65, 75, 90), width=3)
    draw.text((45, 525), "Payroll Clerk", font=F_SMALL, fill=(35, 35, 40))
    for x, y, text in [(350, 180, "Maintain employee file"), (650, 180, "Record attendance"), (350, 340, "Calculate salaries"), (650, 340, "Prepare payslips"), (500, 500, "Update ledger")]:
        draw.ellipse((x, y, x + 250, y + 75), fill=(248, 250, 252), outline=(90, 111, 140), width=3)
        centered_text(draw, (x, y, x + 250, y + 75), text, F_SMALL)
        draw_arrow(draw, (145, 335), (x, y + 38), width=2)
    paths.append(save(image, "figure4_existing_usecase.png"))

    image, draw = canvas("Existing System Activity Flow")
    activity = ["Start", "Collect employee details", "Mark attendance manually", "Calculate salary in sheet", "Review and correct errors", "Prepare payslip"]
    rects = []
    y = 105
    for text in activity:
        rect = (420, y, 780, y + 55)
        rects.append(rect)
        draw_box(draw, rect, text, font=F_SMALL)
        y += 105
    for a, b in zip(rects, rects[1:]):
        draw_arrow(draw, ((a[0] + a[2]) // 2, a[3]), ((b[0] + b[2]) // 2, b[1]))
    paths.append(save(image, "figure5_existing_activity.png"))

    image, draw = canvas("Proposed System Sequence")
    xs = [120, 320, 520, 720, 920, 1080]
    labels = ["User", "MVC UI", "Auth", "Repository", "SQL Server", "Dashboard"]
    for x, label in zip(xs, labels):
        draw_box(draw, (x - 70, 110, x + 70, 165), label, font=F_SMALL)
        draw.line((x, 165, x, 670), fill=(165, 165, 175), width=2)
    steps = [(120, 320, 220, "login/register"), (320, 520, 285, "validate role"), (520, 720, 350, "request data"), (720, 920, 415, "execute query"), (920, 720, 480, "return rows"), (720, 1080, 545, "view model"), (1080, 120, 610, "render allowed data")]
    for a, b, y, text in steps:
        draw_arrow(draw, (a, y), (b, y))
        draw.text((min(a, b) + 15, y - 25), text, font=F_SMALL, fill=(45, 55, 70))
    paths.append(save(image, "figure6_proposed_sequence.png"))

    image, draw = canvas("Proposed System Architecture")
    for rect, text in [
        ((60, 170, 285, 310), "Browser UI\nRazor Views"),
        ((380, 110, 650, 230), "ASP.NET Core MVC\nControllers"),
        ((380, 330, 650, 450), "Session and Role\nAuthorization"),
        ((760, 210, 1010, 350), "Repository Layer\nADO.NET Queries"),
        ((760, 480, 1010, 620), "SQL Server DB\nSSMS / SQLEXPRESS"),
    ]:
        draw_box(draw, rect, text)
    for a, b in [((285, 240), (380, 170)), ((285, 240), (380, 390)), ((650, 170), (760, 260)), ((650, 390), (760, 260)), ((885, 350), (885, 480))]:
        draw_arrow(draw, a, b)
    paths.append(save(image, "figure7_proposed_architecture.png"))

    image, draw = canvas("Proposed System Use Case")
    draw.rounded_rectangle((250, 90, 1140, 690), radius=24, outline=(120, 135, 160), width=3)
    for name, x, y in [("Admin", 80, 130), ("HR", 80, 350), ("Accountant", 80, 555), ("Employee", 1060, 350)]:
        draw.ellipse((x, y, x + 50, y + 50), outline=(65, 75, 90), width=3)
        draw.line((x + 25, y + 50, x + 25, y + 125), fill=(65, 75, 90), width=3)
        draw.line((x - 15, y + 80, x + 65, y + 80), fill=(65, 75, 90), width=3)
        draw.line((x + 25, y + 125, x - 5, y + 180), fill=(65, 75, 90), width=3)
        draw.line((x + 25, y + 125, x + 55, y + 180), fill=(65, 75, 90), width=3)
        draw.text((x - 18, y + 190), name, font=F_SMALL, fill=(35, 35, 40))
    cases = [(330, 140, "Manage users"), (620, 140, "Manage employees"), (330, 300, "Approve leaves"), (620, 300, "Mark attendance"), (330, 460, "Generate payroll"), (620, 460, "View ledgers"), (850, 300, "Check in/out"), (850, 460, "View own payroll")]
    for x, y, text in cases:
        draw.ellipse((x, y, x + 220, y + 70), fill=(248, 250, 252), outline=(90, 111, 140), width=3)
        centered_text(draw, (x, y, x + 220, y + 70), text, F_SMALL)
    paths.append(save(image, "figure8_proposed_usecase.png"))

    image, draw = canvas("Proposed Payroll Processing Activity")
    activity = ["Start", "Login and identify role", "Open authorized module", "Select employee and month", "Calculate salary plus allowance", "Save payroll and ledgers"]
    rects = []
    y = 100
    for text in activity:
        rect = (410, y, 790, y + 55)
        rects.append(rect)
        draw_box(draw, rect, text, font=F_SMALL)
        y += 100
    for a, b in zip(rects, rects[1:]):
        draw_arrow(draw, ((a[0] + a[2]) // 2, a[3]), ((b[0] + b[2]) // 2, b[1]))
    paths.append(save(image, "figure9_proposed_activity.png"))
    return paths


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def write_cell(cell, text, bold=False):
    cell.text = ""
    p = cell.paragraphs[0]
    r = p.add_run(text)
    r.bold = bold
    r.font.name = "Times New Roman"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    r.font.size = Pt(10.5)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(doc, rows, widths):
    table = doc.add_table(rows=1, cols=len(rows[0]))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    for i, header in enumerate(rows[0]):
        set_cell_shading(table.rows[0].cells[i], "E8EEF5")
        write_cell(table.rows[0].cells[i], header, True)
    for row in rows[1:]:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            write_cell(cells[i], value)
    for row in table.rows:
        for i, width in enumerate(widths):
            row.cells[i].width = Inches(width)
    return table


def add_page_number(field_paragraph):
    field_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    field_paragraph.text = ""


def para(doc, text="", bold=False, italic=False, align=None):
    p = doc.add_paragraph()
    if align is not None:
        p.alignment = align
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    return p


def bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.add_run(text)


def number(doc, text):
    p = doc.add_paragraph(style="List Number")
    p.add_run(text)


def heading(doc, text, level=1):
    doc.add_heading(text, level=level)


def add_image_page(doc, title, path, caption):
    heading(doc, title, 2)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(path), width=Inches(6.15))
    cap = doc.add_paragraph(caption)
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.runs[0].italic = True


def configure_doc():
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)
    styles = doc.styles
    styles["Normal"].font.name = "Times New Roman"
    styles["Normal"]._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    styles["Normal"].font.size = Pt(12)
    styles["Normal"].paragraph_format.space_after = Pt(8)
    styles["Normal"].paragraph_format.line_spacing = 1.15
    for name in ["Title", "Heading 1", "Heading 2", "Heading 3"]:
        styles[name].font.name = "Times New Roman"
        styles[name]._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        styles[name].font.bold = True
    styles["Heading 1"].font.size = Pt(18)
    styles["Heading 1"].font.color.rgb = RGBColor(0, 0, 0)
    styles["Heading 1"].paragraph_format.space_before = Pt(18)
    styles["Heading 1"].paragraph_format.space_after = Pt(10)
    styles["Heading 2"].font.size = Pt(15)
    styles["Heading 2"].font.color.rgb = RGBColor(0, 0, 0)
    styles["Heading 2"].paragraph_format.space_before = Pt(14)
    styles["Heading 2"].paragraph_format.space_after = Pt(8)
    styles["Heading 3"].font.size = Pt(13)
    styles["Heading 3"].font.color.rgb = RGBColor(0, 0, 0)
    styles["Heading 3"].paragraph_format.space_before = Pt(10)
    styles["Heading 3"].paragraph_format.space_after = Pt(6)
    section.header.paragraphs[0].text = ""
    add_page_number(section.footer.paragraphs[0])
    return doc


def body_pages():
    return [
        ("Chapter 1: Introduction", [
            "Automated Payroll Management System is a web-based business application designed to manage employee records, attendance, leaves, payroll generation, and accounting ledger entries in a structured digital environment. In many small and medium organizations, salary processing is still handled through manual registers, spreadsheets, and disconnected files. This creates delays, calculation mistakes, weak record tracking, and difficulty in maintaining privacy of employee salary information.",
            "The proposed system is developed using ASP.NET Core MVC with C# for the application layer and Microsoft SQL Server for database management. The MVC structure separates controllers, views, models, and data access logic, making the system easier to maintain and explain. The interface is dashboard based so that Admin, HR, Accountant, and Employee users can access modules according to their assigned roles.",
            ("1.1 Problem Statement", 2),
            "Manual payroll processing is time consuming and prone to errors because employee information, attendance, leaves, allowances, and salary calculations are often stored in separate files. When data is scattered across registers or spreadsheets, HR staff and accountants must repeatedly verify the same information before preparing monthly salaries. This increases the chance of incorrect salary slips, missing attendance entries, and delayed payroll generation.",
        ]),
        ("1.2 Project Objective", [
            "The primary objective of the Automated Payroll Management System is to develop a dashboard-style payroll management system that helps an organization manage payroll activities in a reliable, organized, and user-friendly manner. The system aims to replace manual payroll handling with a centralized web application where employee data, attendance, leaves, payroll, and accounting records can be maintained through a single database-driven platform.",
            "Another objective is to implement role-based access control. Admin users should manage the overall system, HR users should manage employee records, attendance, and leave activities, accountants should manage payroll and ledgers, and employees should only access their personal records. This supports data privacy and prevents unauthorized users from viewing or modifying information outside their responsibility.",
            "The project also aims to automate payroll calculation by combining employee basic salary with selected allowance details and storing payroll results in structured payroll and payroll detail tables. At the same time, employee ledger and general ledger entries are generated to support financial tracking.",
        ]),
        ("Chapter 2: Existing System (Manual Payroll Process)", [
            ("2.1 System Scope", 2),
            "The existing system in many organizations is based on manual payroll processing or spreadsheet-based salary management. Its scope is usually limited to maintaining employee information, recording attendance, approving leaves, calculating salaries, and preparing payslips by hand or through basic spreadsheet formulas.",
            "The scope of the existing system does not usually include role-based dashboards, employee self-service portals, automatic payroll details, or ledger-based accounting entries. Employees often depend on HR or accounts staff for salary information, leave status, and attendance confirmation.",
            ("2.2 Existing System Description", 2),
            "In the existing process, HR staff maintain employee files manually or in spreadsheets. Attendance may be recorded in registers, biometric exports, or separate sheets. Leave requests may be written on paper or sent through informal communication channels. At the end of the month, salary is calculated by checking basic salary, attendance, leaves, allowances, and other adjustments.",
        ]),
        ("2.3 Product Perspective", [
            "The existing payroll environment can be viewed as a semi-manual office process rather than an integrated software system. It depends heavily on human coordination among HR, accounts, and management staff. The process is not modular and does not have a proper database relationship between employees, attendance, leaves, payroll, and ledger records.",
            ("2.4 Functional Overview", 2),
            "The existing system performs basic payroll functions such as adding employee details, marking attendance, recording leaves, calculating monthly salary, and preparing payslips. However, most of these functions are performed manually by different people. Data validation depends on the person entering the data, and there is no automatic warning when required information is missing.",
            ("2.5 System Architecture", 2),
            "The architecture of the existing system is informal. Employee files, attendance sheets, leave records, payroll sheets, and account ledgers exist as separate components. Data moves from one component to another through manual entry or copying. There is no centralized database, no MVC layer, and no role-based application interface.",
        ]),
        ("2.6 Comparison Table", ["TABLE_COMPARISON"]),
        ("Chapter 3: Proposed System", [
            ("3.1 Introduction", 2),
            "The proposed Automated Payroll Management System is a web-based application designed to automate and organize payroll activities for an organization. It provides a central platform where employee data, attendance, leave requests, payroll generation, allowance handling, payslip viewing, and accounting ledgers can be managed through a structured role-based dashboard.",
            "The system uses ASP.NET Core MVC as the application framework. MVC divides the system into Models for data structures, Views for user interface pages, and Controllers for request handling. SQL Server is used as the database system, while repository classes handle communication between the application and database.",
            ("3.1.1 Purpose", 3),
            "The purpose of this SRS is to define the functional and non-functional requirements of the Automated Payroll Management System. It explains what the system shall do, which users will interact with it, what database records are required, and how different modules such as employees, attendance, leaves, payroll, and accounts work together.",
        ]),
        ("3.1.2 Scope", [
            "The scope of the Automated Payroll Management System includes employee profile management, role-based login, user registration, attendance management, leave management, payroll generation, allowance entry, payslip viewing, employee ledger, and general ledger functionality. The system is designed for four main roles: Admin, HR, Accountant, and Employee.",
            "The system is limited to organizational payroll management and does not include banking integration, tax filing integration, biometric hardware integration, or external enterprise resource planning integration. These features can be added in future versions, but the current project focuses on the core payroll workflow required for an academic final year project.",
            ("3.2 Overall Description", 2),
            ("3.2.1 Product Perspective", 3),
            "The Automated Payroll Management System is a standalone web application that runs on a local or hosted server and stores data in SQL Server. It is built as a business information system rather than a public website. Users interact with the system through browser-based dashboards.",
        ]),
        ("3.2.2 Product Functions", [
            "The system provides user authentication and registration. New accounts can be created for Admin, HR, Accountant, or Employee roles. When an employee account is created, it is linked with an employee record so that the employee can only view personal attendance, leave, dashboard, and payroll information.",
            "The employee management module allows authorized users to add, update, view, and deactivate employee records. Each employee record includes employee code, name, father name, gender, CNIC, contact details, department, designation, joining date, basic salary, and active status.",
            "The attendance module allows employees to check in and check out from their own portal. Admin and HR users can also mark attendance manually as present, absent, half day, or leave. The leave module records leave requests and status. The payroll module generates salary records and ledger entries.",
        ]),
        ("3.2.3 User Classes and Characteristics", [
            "BULLET:Admin: The admin controls the overall system, can register users, and can access major modules according to system policy.",
            "BULLET:HR: The HR user manages employee records, attendance, and leave activities.",
            "BULLET:Accountant: The accountant manages payroll generation and ledger records.",
            "BULLET:Employee: The employee has limited access and can only view personal dashboard, attendance, leaves, and payroll information.",
            ("3.2.4 Operating Environment", 2),
            "The system operates in a web application environment. It requires Visual Studio 2022 Community Edition, .NET 8 SDK, SQL Server Express, and SQL Server Management Studio. Client users access the system through a modern web browser such as Google Chrome or Microsoft Edge.",
        ]),
        ("3.2.5 Design and Implementation Constraints", [
            "The system is constrained by the academic project scope and development timeline. Therefore, advanced enterprise features such as biometric device integration, bank payment gateway integration, tax return automation, and cloud deployment automation are not included in the current version.",
            "The system uses session-based authentication and role authorization suitable for an academic MVC project. Password storage in the current prototype is simple for learning purposes; in a production-level system, password hashing and stronger identity management should be implemented.",
            ("3.3 Functional Requirements", 1),
            ("3.3.1 User Authentication Requirements", 2),
            "The system shall allow users to log in using a unique username and password. After successful authentication, the system shall store the user role and user identity in session so that protected modules can be accessed according to permission level.",
        ]),
        ("3.3.2 Employee Management Requirements", [
            "The system shall allow Admin and HR users to add, edit, view, and deactivate employees. The employee form shall validate required fields such as employee code, full name, father name, gender, CNIC, phone, email, address, department, designation, joining date, and salary.",
            "Employee codes such as EMP001, EMP002, and future employee codes shall identify employee records. Registering a login account does not create a new employee; the employee must first be created in the employee module and then linked to a login account if needed.",
            ("3.3.3 Attendance Management Requirements", 2),
            "The system shall allow employees to mark their own check-in and check-out through the employee portal. Admin and HR users shall be able to mark attendance for any employee as Present, Absent, Half Day, or Leave.",
        ]),
        ("3.3.4 Leave Management Requirements", [
            "The system shall allow leave records to be created with employee, leave type, start date, end date, reason, and status. Employees shall be able to submit their own leave requests, while Admin and HR users shall approve or reject leave requests according to organizational rules.",
            ("3.3.5 Payroll Processing Requirements", 2),
            "The system shall allow Admin and Accountant users to generate monthly payroll for employees. Payroll generation shall use employee basic salary, payroll month, payroll year, allowance type, and allowance amount. The net salary shall be calculated by adding basic salary and allowance amount.",
            "The selected allowance type, such as Car, Incentives, House, Medical Allowance, Overtime Allowance, or House Rent Allowance, shall appear clearly in the payroll slip and employee ledger.",
        ]),
        ("3.3.6 Accounts and Ledger Requirements", [
            "The system shall maintain a GeneralLedger table for company-level payroll financial entries. When payroll is generated, the system shall create a general ledger entry that records the salary payment effect on company accounts.",
            "The system shall also maintain an EmployeeLedger table for employee-specific payroll entries. The employee ledger shall include employee ID, payroll ID, allowance type, transaction date, description, debit, credit, and balance. This helps track payroll history and allowance-related salary entries for each employee.",
            ("3.4 Non-Functional Requirements", 1),
            ("3.4.1 Performance Requirements", 2),
            "The system shall respond quickly to common user actions such as login, dashboard loading, employee listing, attendance submission, leave saving, payroll generation, and payslip viewing.",
        ]),
        ("3.4.2 Security Requirements", [
            "The system shall restrict access through role-based authorization. Admin, HR, Accountant, and Employee users shall not have the same permissions. Employee users shall only access personal attendance, leaves, dashboard, and payroll records.",
            "The system shall prevent unauthorized users from accessing protected routes. If a user attempts to access a module without the required role, the system shall redirect or deny access. For production use, password hashing, HTTPS, and stronger audit logging should be implemented.",
            ("3.4.3 Usability Requirements", 2),
            "The system shall provide a simple dashboard-style interface with clear navigation links. Forms shall use labels, dropdowns, date fields, numeric fields, and validation messages to reduce confusion during data entry.",
        ]),
        ("3.4.4 Reliability Requirements", [
            "The system shall reliably store each transaction in the SQL Server database. Payroll generation shall save payroll summary, payroll details, general ledger, and employee ledger information consistently. If payroll processing fails during a transaction, partial data should not be saved.",
            "The system shall update existing daily attendance records instead of creating duplicate attendance rows for the same employee and date. This improves data reliability and ensures attendance reports remain accurate.",
            ("3.4.5 Availability Requirements", 2),
            "The system shall be available whenever the local server and SQL Server database are running. In a development environment, it can be launched from Visual Studio 2022 or using the dotnet run command.",
        ]),
        ("3.4.6 Compatibility Requirements", [
            "The system shall be compatible with .NET 8, ASP.NET Core MVC, SQL Server Express, SQL Server Management Studio, and modern web browsers. The interface shall work on common desktop screen sizes and remain usable on smaller screens through responsive layout behavior.",
            ("3.5 External Interface Requirements", 1),
            ("3.5.1 User Interface Requirements", 2),
            "The system shall provide a web-based user interface with dashboard cards, navigation sidebar, forms, tables, buttons, and validation messages. Each module shall be presented in a clean layout so users can quickly understand the available actions.",
        ]),
        ("3.5.2 Hardware Interface Requirements", [
            "The system does not require any special hardware. It can run on a standard computer capable of running Visual Studio, .NET SDK, SQL Server Express, and a modern web browser. Future versions may integrate biometric attendance devices, but the current scope uses software-based attendance marking.",
            ("3.5.3 Software Interface Requirements", 2),
            "The system interfaces with SQL Server using ADO.NET through repository methods. ASP.NET Core MVC handles routing, controllers, model binding, and Razor views. SQL Server Management Studio is used for database creation, query execution, and database inspection.",
            ("3.5.4 Communication Interface Requirements", 2),
            "The browser communicates with the ASP.NET Core MVC server through HTTP or HTTPS requests. Form submissions are processed by controllers, and controllers call repository methods to read or write database records.",
        ]),
        ("3.6 System Features", [
            ("3.6.1 User Authentication and Registration System", 2),
            "This feature manages login, logout, session data, role selection, and user registration. Each user has individual login information. Employee accounts are connected with employee records so that private employee pages show only the logged-in employee information.",
            ("3.6.2 Employee Management System", 2),
            "This feature manages employee master data including code, name, CNIC, contact information, department, designation, joining date, salary, and active status. It acts as the foundation for attendance, leave, payroll, and user account linking.",
            ("3.6.3 Attendance Management System", 2),
            "This feature records employee attendance. Employees can check in and check out through their own portal, while Admin and HR can mark attendance manually for employees when required.",
        ]),
        ("3.6.4 Leave Management System", [
            "This feature records leave requests and status values. Employees can submit leave requests, and authorized users can approve or reject them. Leave records are filtered according to role so employees see only their own data.",
            ("3.6.5 Payroll Generation System", 2),
            "This feature generates payroll using employee salary, payroll month, payroll year, allowance type, and allowance amount. It stores payroll summary and payroll detail records and supports payslip viewing for authorized users.",
            ("3.6.6 Allowance Handling System", 2),
            "This feature allows Admin or Accountant users to mark allowance information during payroll generation. Supported allowance names include Car, Incentives, House, Medical Allowance, Overtime Allowance, and House Rent Allowance.",
        ]),
        ("3.6.7 Accounts and Ledger System", [
            "This feature records payroll-related financial entries in the general ledger and employee ledger. The general ledger represents company-level salary payment effects, while the employee ledger maintains employee-specific payroll history.",
            ("3.6.8 Dashboard and Reporting System", 2),
            "This feature provides summary information such as active employees, departments, present employees, pending leaves, and payroll totals. The dashboard changes according to the logged-in role, especially for employee users who should see only personal data.",
        ]),
        ("3.7 Other Requirements", [
            ("3.7.1 Database Requirements", 2),
            "The database shall contain normalized tables for Roles, Users, Departments, Designations, Employees, Attendance, Leaves, Payroll, PayrollDetails, EmployeeLedger, GeneralLedger, and AuditLogs. Primary keys shall uniquely identify records, and foreign keys shall maintain relationships between employee, payroll, and ledger data.",
            "The Users table shall include RoleID and EmployeeID. RoleID connects the user to a system role, while EmployeeID links an employee login account to the employee master record. This relationship is essential for restricting employee users to their own records.",
            ("3.7.2 Documentation Requirements", 2),
            "The project shall include database scripts, source code, and this SRS document. The documentation should be clear enough for evaluators to understand the purpose, modules, database relationships, and workflows of the system.",
        ]),
        ("3.7.3 Training and Future Requirements", [
            "Basic training is required for Admin, HR, Accountant, and Employee users. Admin and HR users should understand employee, attendance, and leave workflows. Accountants should understand payroll generation and ledger views. Employees should understand login, attendance check-in/check-out, leave request, and payslip viewing.",
            ("3.7.4 Reliability Requirements", 2),
            "The system shall protect data consistency by validating input and saving related payroll records together. During payroll generation, summary, detail, and ledger records are created as one workflow, reducing the possibility of missing financial records.",
            ("3.7.5 Scalability Requirements", 2),
            "The current version is designed for small and medium organizations. Future scalability can be improved by adding pagination, reporting filters, stored procedures, and identity-based authentication.",
            ("3.7.6 Compatibility Requirements", 2),
            "The database script should be kept updated whenever schema changes are made so that the project can be recreated on another machine during evaluation.",
        ]),
    ]


def extra_theory():
    return {
        "Chapter 1: Introduction": [
            "Payroll management is one of the most sensitive administrative functions in an organization because it directly affects employee satisfaction, financial planning, and record transparency. A payroll system does not only calculate salaries; it also connects human resource records, attendance, leaves, allowances, and accounting entries into one controlled workflow. If any one of these components is inaccurate, the final salary calculation can become unreliable. For this reason, payroll automation is considered an important part of organizational information systems.",
            "In an automated payroll environment, every employee record becomes a reusable source of information for multiple modules. The same employee ID can be used in attendance, leave, payroll, user login, and ledger records. This reduces duplication and improves data consistency. The proposed system follows this idea by using relational database tables where primary keys and foreign keys connect the business entities in a meaningful way.",
        ],
        "1.2 Project Objective": [
            "A further objective is to demonstrate how a real business process can be converted into a software workflow. The project is not limited to designing screens; it also shows how data travels from the user interface to the controller, from the controller to the repository, and from the repository to SQL Server. This makes the project suitable for explaining both software engineering concepts and database concepts during viva.",
            "The system also aims to support accountability. When payroll is generated, the salary amount is not only shown on a payslip but also recorded in ledger tables. This means the system can explain why a salary amount exists and how it contributes to financial records. Such traceability is important in payroll systems because salary payments are financial transactions, not only HR records.",
        ],
        "Chapter 2: Existing System (Manual Payroll Process)": [
            "A manual payroll process usually grows informally over time. At the beginning, a small organization may keep employee information in files and calculate salary manually. However, as the organization grows, the same method becomes difficult to control. More employees mean more attendance records, more leave requests, more allowance adjustments, and more salary calculations. Without a proper system, the workload increases faster than the ability to manage it accurately.",
            "The existing system also lacks a strong validation mechanism. For example, a missing CNIC, incorrect salary value, unrecorded leave, or duplicate attendance entry may not be detected immediately. These problems may appear only at the time of payroll calculation, when correction becomes more difficult. A digital system can reduce this problem by validating fields at the time of data entry.",
        ],
        "2.3 Product Perspective": [
            "From an organizational perspective, the existing process is person-dependent rather than system-dependent. If the person responsible for payroll is absent or leaves the organization, the process becomes difficult for another person to continue because much of the knowledge is stored informally. A proper information system reduces this dependency by storing rules, records, and workflows in a structured application.",
            "Another limitation is reporting. Manual systems do not provide quick summaries such as active employees, employees present today, pending leave requests, or monthly payroll total. Such information must be calculated separately, which consumes time and may produce inconsistent results if different files are used.",
        ],
        "2.6 Comparison Table": [
            "The comparison shows that the proposed system improves the existing process in three main areas: data centralization, access control, and process automation. Centralization means that employee, attendance, leave, payroll, and ledger information are stored in one database. Access control means that users only see the modules relevant to their role. Process automation means that payroll and ledger entries are generated through system logic rather than repeated manual calculation.",
        ],
        "Chapter 3: Proposed System": [
            "The proposed system follows the concept of a layered web application. The presentation layer contains Razor views and user interface forms. The controller layer receives requests, validates user roles, and decides which repository method should be called. The data access layer communicates with SQL Server and returns structured objects to the controller. This separation makes the project easier to maintain because changes in one part of the system do not unnecessarily disturb other parts.",
            "The system also uses a role-based access model. Role-based access is important because payroll information is confidential. An employee should not see another employee salary or leave details, while an accountant should not necessarily manage employee personal information unless the system policy allows it. By separating Admin, HR, Accountant, and Employee responsibilities, the system reflects a more realistic organization.",
        ],
        "3.1.2 Scope": [
            "The scope includes both administrative and self-service features. Administrative features are used by Admin, HR, and Accountant users to manage records and generate payroll. Self-service features are used by employees to check attendance, submit leaves, and view personal payroll details. This combination is useful because modern payroll systems are expected to reduce dependency on HR staff by giving employees controlled access to their own information.",
            "The scope also includes database-backed reporting through dashboard cards and tables. Although the system does not include advanced analytics, it provides important operational summaries that help users understand current employee and payroll status. These summaries are generated from database records rather than manually prepared reports.",
        ],
        "3.2.2 Product Functions": [
            "Each product function is connected with a database entity. For example, employee management uses the Employees table, attendance management uses the Attendance table, leave management uses the Leaves table, payroll processing uses Payroll and PayrollDetails, and accounting views use GeneralLedger and EmployeeLedger. This makes the system data-driven and easier to test because each module has a clear storage responsibility.",
            "The registration feature improves the earlier demo-login limitation by allowing separate credentials for different users. This means each employee can have an individual username and password. When an employee login is linked to an employee record, the system can filter information automatically based on the logged-in employee ID.",
        ],
        "3.2.5 Design and Implementation Constraints": [
            "The project intentionally keeps the design understandable for academic evaluation. Instead of using a very complex enterprise identity framework, it uses a simpler session-based approach so that login, role checking, and employee filtering can be explained clearly. This design decision supports learning and demonstration while still achieving the required role-based behavior.",
            "Another constraint is that the system currently handles allowance as part of payroll generation and payroll details rather than maintaining a separate complex allowance configuration module. This keeps the database simpler while still satisfying the requirement that allowance type and allowance amount should appear in payroll and employee ledger records.",
        ],
        "3.3.2 Employee Management Requirements": [
            "Employee management is the master-data module of the system. Master data means the core information that other modules depend on. If an employee record is incomplete or incorrect, attendance, leave, payroll, and account records may also become unreliable. Therefore, employee form validation is necessary to ensure that important information is entered before the employee is saved.",
            "The employee code provides a human-readable identifier such as EMP001 or EMP008, while EmployeeID is the internal database identity value. This distinction is important because users can recognize employee codes easily, while the database can maintain relationships through numeric keys.",
        ],
        "3.3.5 Payroll Processing Requirements": [
            "Payroll processing is the central business function of the system. It combines employee master data with monthly payroll input and allowance information to produce a net salary. The system stores the result in two levels: payroll summary and payroll details. The summary stores the main salary result, while payroll details explain the components included in that salary.",
            "A payroll system should be traceable. If a salary slip shows a net salary, the system should also show how that amount was calculated. For this reason, the basic salary and allowance lines are stored separately in PayrollDetails. This improves transparency and allows the payslip to show salary components clearly.",
        ],
        "3.3.6 Accounts and Ledger Requirements": [
            "Ledger records provide an accounting view of payroll activity. The GeneralLedger represents the organization's financial side, while EmployeeLedger represents the employee-specific salary history. This separation is useful because management may need company-level financial records, while an employee or accountant may need employee-specific payroll history.",
            "The EmployeeLedger also stores the allowance type, which helps explain what kind of allowance was included in a payroll entry. This is useful for viva explanation because it shows that the system does not only store a final salary number; it also stores meaningful supporting information.",
        ],
        "3.4.2 Security Requirements": [
            "Security in this system is based on authentication, authorization, and data filtering. Authentication verifies who the user is. Authorization verifies what role the user has. Data filtering ensures that even after login, an employee only receives records connected to their own EmployeeID. These three concepts work together to protect sensitive payroll data.",
            "The system also demonstrates the principle of least privilege. This means each user should only receive the minimum access required to perform their work. For example, employees do not need access to the employee list or general ledger, while accountants need payroll and ledger access but do not necessarily need leave approval access.",
        ],
        "3.4.3 Usability Requirements": [
            "Usability is especially important because payroll systems may be used by non-technical office staff. A good interface should reduce mistakes by using clear labels, dropdown lists, required field messages, and consistent button placement. The proposed system uses dashboard cards, sidebar navigation, form validation, and tables to make common workflows easier to understand.",
            "The system also improves usability by hiding unnecessary modules from users. When an employee logs in, the sidebar shows only employee-related options. This reduces confusion and also supports security because users are not encouraged to open modules that are outside their role.",
        ],
        "3.5.1 User Interface Requirements": [
            "The user interface should maintain consistency across modules. Consistency means that forms, buttons, tables, headings, and alerts follow the same design pattern throughout the system. This helps users learn one module and then understand other modules more quickly. A dashboard-style layout is suitable for this project because payroll systems require frequent movement between summary views and detailed records.",
            "Validation messages are also part of the interface requirements. If a user skips a required field such as CNIC, salary, or employee selection, the system should clearly inform the user about the missing field. This prevents incomplete records from entering the database and improves the overall quality of stored data.",
        ],
        "3.6 System Features": [
            "The features of the system are designed around real payroll responsibilities. HR-related features manage employee data, attendance, and leaves. Accounting-related features manage payroll and ledgers. Employee-related features provide self-service access to personal records. This feature division makes the system easier to explain because each feature belongs to a clear business role.",
        ],
        "3.7 Other Requirements": [
            "Other requirements define the supporting conditions needed for the system to remain useful after development. A project is not complete only because it runs; it should also be documented, maintainable, understandable, and extendable. This is why database requirements, documentation requirements, training requirements, reliability requirements, scalability requirements, and compatibility requirements are included in the SRS.",
        ],
        "3.7.3 Training and Future Requirements": [
            "Future enhancement planning is important because an SRS should describe not only the current system but also the direction in which the system can grow. Features such as password hashing, biometric attendance integration, PDF payslip export, email notification, tax calculation, and bank payment file generation can convert the project into a more complete commercial payroll solution.",
        ],
    }


def build():
    figs = make_diagrams()
    doc = configure_doc()

    for _ in range(2):
        para(doc)
    if USP_LOGO.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(USP_LOGO), width=Inches(1.35))
        para(doc)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Automated Payroll Management System")
    r.bold = True
    r.font.name = "Times New Roman"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    r.font.size = Pt(26)
    r.font.color.rgb = RGBColor(0, 0, 0)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Software Requirements Specification (SRS)")
    r.font.name = "Times New Roman"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    r.font.size = Pt(18)
    r.font.color.rgb = RGBColor(0, 0, 0)
    for line in [
        "",
        "",
        "Department of Computer Science & IT",
        "",
        "Submitted By:",
        "Mr. M. Taimoor Shakeel",
        "Mr. Rana Ahad",
        "Mr. Umer Farooq",
        "",
        "Submitted To:",
        "Mr. M. Abrar Chughtai",
        "",
        "University of Southern Punjab, Multan",
        "2026",
    ]:
        p = doc.add_paragraph(line)
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_page_break()

    heading(doc, "Table of Contents", 1)
    toc = [
        ("Chapter 1: Introduction", "1"), ("1.1 Problem Statement", "1"), ("1.2 Project Objective", "2"),
        ("Chapter 2: Existing System (Manual Payroll Process)", "3"), ("2.1 System Scope", "3"),
        ("2.2 Existing System Description", "3"), ("2.3 Product Perspective", "4"), ("2.4 Functional Overview", "4"),
        ("2.5 System Architecture", "4"), ("2.6 Comparison Table", "5"), ("2.7 Diagrams (Existing System)", "6"),
        ("Chapter 3: Proposed System", "11"), ("3.1 Introduction", "11"), ("3.2 Overall Description", "12"),
        ("3.3 Functional Requirements", "15"), ("3.4 Non-Functional Requirements", "19"),
        ("3.5 External Interface Requirements", "22"), ("3.6 System Features", "24"),
        ("3.7 Other Requirements", "27"), ("3.8 Diagrams (Proposed System)", "28"), ("References", "32"),
    ]
    for title, num in toc:
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(Inches(6.1))
        p.add_run(title)
        p.add_run("\t" + num)
    doc.add_page_break()

    heading(doc, "List of Figures", 1)
    for i, name in enumerate(["Existing System ERD / Manual Record Structure", "Existing System Sequence", "Existing System Architecture", "Existing System Use Case", "Existing System Activity", "Proposed System Sequence", "Proposed System Architecture", "Proposed System Use Case", "Proposed System Activity"], 1):
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(Inches(6.1))
        p.add_run(f"Figure {i}. {name}")
        p.add_run("\t" + str(5 + i if i <= 5 else 22 + i))
    heading(doc, "List of Tables", 1)
    p = doc.add_paragraph()
    p.paragraph_format.tab_stops.add_tab_stop(Inches(6.1))
    p.add_run("Table 1. Comparison between the existing system and the proposed system.")
    p.add_run("\t5")
    doc.add_page_break()

    comparison = [
        ["Comparison Area", "Existing System", "Proposed Automated Payroll Management System"],
        ["User Interface", "Manual forms, registers, or spreadsheets", "Dashboard-style ASP.NET Core MVC interface"],
        ["Architecture", "Disconnected files and manual workflow", "MVC application with repository and SQL Server database"],
        ["Data Storage", "Paper files or spreadsheet data", "Structured relational database in SQL Server"],
        ["Authentication", "Usually absent or shared access", "Individual login accounts with roles"],
        ["Employee Access", "Employees depend on HR/accounts staff", "Employees view only their own records"],
        ["Attendance", "Manual marking and later verification", "Admin/HR marking plus employee check-in/check-out"],
        ["Payroll Calculation", "Manual formula-based calculation", "Automated payroll generation with allowance support"],
        ["Ledger Records", "Separate manual account ledger", "General ledger and employee ledger entries"],
        ["Security", "Limited privacy and weak control", "Role-based access and session handling"],
    ]

    additions = extra_theory()

    for title, contents in body_pages()[:5]:
        heading(doc, title, 1 if title.startswith("Chapter") else 2)
        for item in contents:
            if item == "TABLE_COMPARISON":
                para(doc, "Table 1. Comparison between the existing system and the proposed system.", italic=True)
                add_table(doc, comparison, [1.45, 2.45, 2.45])
            elif isinstance(item, tuple):
                heading(doc, item[0], item[1])
            elif isinstance(item, str) and item.startswith("BULLET:"):
                bullet(doc, item.replace("BULLET:", "", 1))
            else:
                para(doc, item)
        for item in additions.get(title, []):
            para(doc, item)
        doc.add_page_break()

    for title, fig, caption in [
        ("2.7 Diagrams (Existing System)\nER Diagram", figs[0], "Figure 1. Existing System ERD / Manual Record Structure"),
        ("Sequence Diagram", figs[1], "Figure 2. Existing System Sequence"),
        ("Architecture Diagram", figs[2], "Figure 3. Existing System Architecture"),
        ("Use Case Diagram", figs[3], "Figure 4. Existing System Use Case"),
        ("Activity Diagram", figs[4], "Figure 5. Existing System Activity"),
    ]:
        add_image_page(doc, title, fig, caption)
        doc.add_page_break()

    for title, contents in body_pages()[5:]:
        heading(doc, title, 1 if title.startswith("Chapter") or title.startswith("3.3") or title.startswith("3.4") or title.startswith("3.5") or title.startswith("3.6") or title.startswith("3.7") else 2)
        for item in contents:
            if isinstance(item, tuple):
                heading(doc, item[0], item[1])
            elif isinstance(item, str) and item.startswith("BULLET:"):
                bullet(doc, item.replace("BULLET:", "", 1))
            else:
                para(doc, item)
        for item in additions.get(title, []):
            para(doc, item)
        doc.add_page_break()

    heading(doc, "3.8 Diagrams (Proposed System)", 1)
    add_image_page(doc, "Sequence Diagram", figs[5], "Figure 6. Proposed System Sequence")
    doc.add_page_break()
    add_image_page(doc, "Architecture Diagram", figs[6], "Figure 7. Proposed System Architecture")
    doc.add_page_break()
    add_image_page(doc, "Use Case Diagram", figs[7], "Figure 8. Proposed System Use Case")
    doc.add_page_break()
    add_image_page(doc, "Activity Diagram", figs[8], "Figure 9. Proposed System Activity")
    doc.add_page_break()

    heading(doc, "REFERENCES", 1)
    for ref in [
        "Microsoft. ASP.NET Core MVC Documentation. Microsoft Learn.",
        "Microsoft. SQL Server and Transact-SQL Documentation. Microsoft Learn.",
        "Microsoft. Visual Studio 2022 Documentation. Microsoft Learn.",
        "Pressman, R. S. Software Engineering: A Practitioner Approach. McGraw-Hill.",
        "Sommerville, I. Software Engineering. Pearson Education.",
        "IEEE. Recommended Practice for Software Requirements Specifications.",
    ]:
        number(doc, ref)
    para(doc, "Note: This SRS has been prepared for the Automated Payroll Management System final year project and is written according to the accepted academic SRS structure provided as a reference. The content, requirements, and diagrams are specific to the Automated Payroll Management System.", italic=True)

    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build()
