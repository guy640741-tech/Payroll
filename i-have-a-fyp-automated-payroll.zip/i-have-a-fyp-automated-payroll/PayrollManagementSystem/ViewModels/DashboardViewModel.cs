using PayrollManagementSystem.Models;

namespace PayrollManagementSystem.ViewModels;

public class DashboardViewModel
{
    public int Employees { get; set; }
    public int Departments { get; set; }
    public int PresentToday { get; set; }
    public int PendingLeaves { get; set; }
    public decimal CurrentMonthPayroll { get; set; }
    public List<Employee> RecentEmployees { get; set; } = [];
    public List<Payroll> RecentPayrolls { get; set; } = [];
    public List<DashboardAttendanceItem> TodayAttendance { get; set; } = [];
}

public class SelectOption
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
}

public class DashboardAttendanceItem
{
    public string EmployeeName { get; set; } = string.Empty;
    public string Status { get; set; } = "Absent";
    public bool IsPresent => Status == "Present";
}

public class PayrollGenerateViewModel
{
    [System.ComponentModel.DataAnnotations.Range(1, int.MaxValue, ErrorMessage = "Employee is required.")]
    public int EmployeeID { get; set; }
    [System.ComponentModel.DataAnnotations.Range(1, 12, ErrorMessage = "Month is required.")]
    public int PayrollMonth { get; set; } = DateTime.Today.Month;
    [System.ComponentModel.DataAnnotations.Range(2020, 2100, ErrorMessage = "Year is required.")]
    public int PayrollYear { get; set; } = DateTime.Today.Year;
    [System.ComponentModel.DataAnnotations.Required(ErrorMessage = "Allowance type is required.")]
    public string AllowanceType { get; set; } = "Car";
    [System.ComponentModel.DataAnnotations.Range(0, 999999999, ErrorMessage = "Allowance is required.")]
    public decimal Allowance { get; set; }
    public List<SelectOption> Employees { get; set; } = [];
    public List<string> AllowanceTypes { get; set; } =
    [
        "Car",
        "Incentives",
        "House",
        "Medical Allowance",
        "Overtime Allowance",
        "House Rent Allowance"
    ];
}
