using System.ComponentModel.DataAnnotations;
using PayrollManagementSystem.Models;

namespace PayrollManagementSystem.ViewModels;

public class RegisterUserViewModel
{
    [Required(ErrorMessage = "Username is required."), StringLength(50)]
    public string Username { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password is required."), StringLength(100, MinimumLength = 4, ErrorMessage = "Password must be at least 4 characters.")]
    public string Password { get; set; } = string.Empty;

    [Required(ErrorMessage = "Confirm password is required.")]
    [Compare(nameof(Password), ErrorMessage = "Password and confirm password do not match.")]
    public string ConfirmPassword { get; set; } = string.Empty;

    [Range(1, int.MaxValue, ErrorMessage = "Role is required.")]
    public int RoleID { get; set; }

    public string RoleName { get; set; } = string.Empty;

    public int? EmployeeID { get; set; }

    public List<Role> Roles { get; set; } = [];

    public List<SelectOption> Employees { get; set; } = [];
}
