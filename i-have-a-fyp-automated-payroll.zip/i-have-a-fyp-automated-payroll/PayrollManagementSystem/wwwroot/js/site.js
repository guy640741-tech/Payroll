document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll("[data-access-menu-toggle]").forEach(function (button) {
    button.addEventListener("click", function () {
      const shell = button.closest(".access-menu-shell");
      if (!shell) {
        return;
      }

      const isOpen = shell.classList.toggle("is-open");
      button.setAttribute("aria-expanded", String(isOpen));
    });
  });

  document.querySelectorAll("[data-password-toggle]").forEach(function (button) {
    button.addEventListener("click", function () {
      const field = button.closest(".password-field");
      const input = field ? field.querySelector("input") : null;

      if (!input) {
        return;
      }

      const showPassword = input.type === "password";
      input.type = showPassword ? "text" : "password";
      button.classList.toggle("is-visible", showPassword);
      button.setAttribute("aria-label", showPassword ? "Hide password" : "Show password");
      button.setAttribute("title", showPassword ? "Hide password" : "Show password");
    });
  });

  document.querySelectorAll("[data-employee-ledger]").forEach(function (button) {
    button.addEventListener("click", function () {
      const form = button.closest("form");
      const input = form ? form.querySelector("#employeeLedgerId") : null;

      if (!form || !input) {
        return;
      }

      input.value = button.getAttribute("data-employee-ledger") || "";
      form.submit();
    });
  });

  document.querySelectorAll("form").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      const requiredFields = Array.from(form.querySelectorAll("[required]"));
      const missing = requiredFields.filter(function (field) {
        return !String(field.value || "").trim();
      });

      if (missing.length === 0) {
        return;
      }

      event.preventDefault();
      missing.forEach(function (field) {
        field.classList.add("is-invalid");
      });

      const first = missing[0];
      const label = form.querySelector("label[for='" + first.id + "']");
      const name = label ? label.textContent.trim() : (first.name || "This field");
      alert(name + " is necessary. Please fill this field.");
      first.focus();
    });
  });
});
