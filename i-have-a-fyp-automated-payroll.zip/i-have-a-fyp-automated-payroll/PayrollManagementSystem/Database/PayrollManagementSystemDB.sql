CREATE DATABASE PayrollManagementSystemDB;
GO

USE PayrollManagementSystemDB;
GO

-----------------------------
-- ROLES
-----------------------------

CREATE TABLE Roles
(
    RoleID INT IDENTITY(1,1) PRIMARY KEY,
    RoleName VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO Roles(RoleName)
VALUES
('Admin'),
('HR'),
('Accountant'),
('Employee');

-----------------------------
-- DEPARTMENTS
-----------------------------

CREATE TABLE Departments
(
    DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
    DepartmentName VARCHAR(100) NOT NULL UNIQUE
);

INSERT INTO Departments(DepartmentName)
VALUES
('HR'),
('Accounts'),
('IT'),
('Sales'),
('Management');

-----------------------------
-- DESIGNATIONS
-----------------------------

CREATE TABLE Designations
(
    DesignationID INT IDENTITY(1,1) PRIMARY KEY,
    DesignationName VARCHAR(100) NOT NULL UNIQUE
);

INSERT INTO Designations(DesignationName)
VALUES
('Manager'),
('HR Officer'),
('Accountant'),
('Software Developer'),
('Sales Executive');

-----------------------------
-- EMPLOYEES
-----------------------------

CREATE TABLE Employees
(
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeCode VARCHAR(20) UNIQUE NOT NULL,
    FullName VARCHAR(100) NOT NULL,
    FatherName VARCHAR(100),
    Gender VARCHAR(10),
    CNIC VARCHAR(20) UNIQUE,
    Phone VARCHAR(20),
    Email VARCHAR(100),
    Address VARCHAR(255),
    DepartmentID INT,
    DesignationID INT,
    JoiningDate DATE,
    BasicSalary DECIMAL(18,2),
    IsActive BIT DEFAULT 1,

    FOREIGN KEY(DepartmentID) REFERENCES Departments(DepartmentID),
    FOREIGN KEY(DesignationID) REFERENCES Designations(DesignationID)
);

INSERT INTO Employees
(
    EmployeeCode,
    FullName,
    FatherName,
    Gender,
    CNIC,
    Phone,
    Email,
    Address,
    DepartmentID,
    DesignationID,
    JoiningDate,
    BasicSalary
)
VALUES
(
    'EMP001',
    'Ali Khan',
    'Ahmed Khan',
    'Male',
    '12345-1234567-1',
    '03001234567',
    'ali@gmail.com',
    'Islamabad',
    3,
    4,
    '2026-01-01',
    80000
);

-----------------------------
-- USERS
-----------------------------

CREATE TABLE Users
(
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(100) NOT NULL,
    RoleID INT NOT NULL,
    EmployeeID INT NULL,
    IsActive BIT DEFAULT 1,

    FOREIGN KEY(RoleID) REFERENCES Roles(RoleID),
    FOREIGN KEY(EmployeeID) REFERENCES Employees(EmployeeID)
);

INSERT INTO Users(Username, Password, RoleID, EmployeeID)
VALUES
('admin', 'admin123', 1, NULL),
('hr', 'hr123', 2, NULL),
('accountant', 'account123', 3, NULL),
('employee', 'employee123', 4, 1);

-----------------------------
-- ATTENDANCE
-----------------------------

CREATE TABLE Attendance
(
    AttendanceID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    AttendanceDate DATE NOT NULL,
    Status VARCHAR(20),
    CheckIn TIME,
    CheckOut TIME,

    FOREIGN KEY(EmployeeID) REFERENCES Employees(EmployeeID)
);

-----------------------------
-- LEAVES
-----------------------------

CREATE TABLE Leaves
(
    LeaveID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT,
    LeaveType VARCHAR(50),
    StartDate DATE,
    EndDate DATE,
    Reason VARCHAR(255),
    Status VARCHAR(30),

    FOREIGN KEY(EmployeeID) REFERENCES Employees(EmployeeID)
);

-- PAYROLL
-----------------------------

CREATE TABLE Payroll
(
    PayrollID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT,
    PayrollMonth INT,
    PayrollYear INT,
    BasicSalary DECIMAL(18,2),
    TotalAllowance DECIMAL(18,2),
    NetSalary DECIMAL(18,2),
    PayrollDate DATE,

    FOREIGN KEY(EmployeeID) REFERENCES Employees(EmployeeID)
);

-- PAYROLL DETAILS
-----------------------------

CREATE TABLE PayrollDetails
(
    DetailID INT IDENTITY(1,1) PRIMARY KEY,
    PayrollID INT,
    Description VARCHAR(100),
    Allowance DECIMAL(18,2) DEFAULT 0,
    Amount DECIMAL(18,2),
    Type VARCHAR(20),

    FOREIGN KEY(PayrollID) REFERENCES Payroll(PayrollID)
);

-- GENERAL LEDGER
-----------------------------

CREATE TABLE GeneralLedger
(
    GeneralLedgerID INT IDENTITY(1,1) PRIMARY KEY,
    PayrollID INT NULL,
    EmployeeID INT NULL,
    TransactionDate DATE NOT NULL,
    Description VARCHAR(255),
    Debit DECIMAL(18,2) DEFAULT 0,
    Credit DECIMAL(18,2) DEFAULT 0,
    Balance DECIMAL(18,2) DEFAULT 0,

    FOREIGN KEY(PayrollID) REFERENCES Payroll(PayrollID),
    FOREIGN KEY(EmployeeID) REFERENCES Employees(EmployeeID)
);

-----------------------------
-- AUDIT LOGS
-----------------------------

CREATE TABLE AuditLogs
(
    LogID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT,
    ActionTaken VARCHAR(255),
    ActionDate DATETIME DEFAULT GETDATE(),

    FOREIGN KEY(UserID) REFERENCES Users(UserID)
);

SELECT * FROM Employees;
