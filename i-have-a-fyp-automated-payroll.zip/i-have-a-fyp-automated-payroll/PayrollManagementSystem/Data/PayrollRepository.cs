using Microsoft.Data.SqlClient;
using PayrollManagementSystem.Models;
using PayrollManagementSystem.ViewModels;

namespace PayrollManagementSystem.Data;

public class PayrollRepository
{
    private readonly DatabaseConnectionFactory _factory;

    public PayrollRepository(DatabaseConnectionFactory factory)
    {
        _factory = factory;
    }

    public async Task<DashboardViewModel> GetDashboardAsync(int? employeeId = null)
    {
        if (employeeId.HasValue)
        {
            var employee = await GetEmployeeAsync(employeeId.Value);
            return new DashboardViewModel
            {
                Employees = employee is null ? 0 : 1,
                Departments = string.IsNullOrWhiteSpace(employee?.DepartmentName) ? 0 : 1,
                PresentToday = await CountAsync("Attendance", "AttendanceDate = CAST(GETDATE() AS DATE) AND Status = 'Present' AND EmployeeID = @EmployeeID", new SqlParameter("@EmployeeID", employeeId.Value)),
                PendingLeaves = await CountAsync("Leaves", "Status = 'Pending' AND EmployeeID = @EmployeeID", new SqlParameter("@EmployeeID", employeeId.Value)),
                CurrentMonthPayroll = await ScalarMoneyAsync("SELECT ISNULL(SUM(NetSalary), 0) FROM Payroll WHERE PayrollMonth = MONTH(GETDATE()) AND PayrollYear = YEAR(GETDATE()) AND EmployeeID = @EmployeeID", new SqlParameter("@EmployeeID", employeeId.Value)),
                RecentEmployees = employee is null ? [] : [employee],
                RecentPayrolls = await GetPayrollsAsync(5, employeeId.Value)
            };
        }

        return new DashboardViewModel
        {
            Employees = await CountAsync("Employees", "IsActive = 1"),
            Departments = await CountAsync("Departments"),
            PresentToday = await CountAsync("Attendance", "AttendanceDate = CAST(GETDATE() AS DATE) AND Status = 'Present'"),
            PendingLeaves = await CountAsync("Leaves", "Status = 'Pending'"),
            CurrentMonthPayroll = await ScalarMoneyAsync("SELECT ISNULL(SUM(NetSalary), 0) FROM Payroll WHERE PayrollMonth = MONTH(GETDATE()) AND PayrollYear = YEAR(GETDATE())"),
            RecentEmployees = await GetEmployeesAsync(),
            RecentPayrolls = await GetPayrollsAsync(5),
            TodayAttendance = await GetDashboardAttendanceAsync()
        };
    }

    public async Task<AppUser?> ValidateLoginAsync(string username, string password)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("""
            SELECT u.UserID, u.Username, u.RoleID, r.RoleName, u.IsActive,
                   CASE WHEN COL_LENGTH('Users', 'EmployeeID') IS NULL THEN NULL ELSE u.EmployeeID END EmployeeID
            FROM Users u
            JOIN Roles r ON u.RoleID = r.RoleID
            WHERE u.Username = @Username AND u.Password = @Password AND u.IsActive = 1
            """, connection);
        command.Parameters.AddWithValue("@Username", username);
        command.Parameters.AddWithValue("@Password", password);
        await connection.OpenAsync();
        using var reader = await command.ExecuteReaderAsync();
        if (!await reader.ReadAsync())
        {
            return null;
        }

        return new AppUser
        {
            UserID = reader.GetInt("UserID"),
            Username = reader.GetText("Username"),
            RoleID = reader.GetInt("RoleID"),
            RoleName = reader.GetText("RoleName"),
            EmployeeID = reader["EmployeeID"] == DBNull.Value ? null : reader.GetInt("EmployeeID"),
            IsActive = reader.GetBool("IsActive")
        };
    }

    public Task<List<Role>> GetRolesAsync() =>
        QueryAsync("SELECT RoleID, RoleName FROM Roles ORDER BY RoleID",
            reader => new Role { RoleID = reader.GetInt("RoleID"), RoleName = reader.GetText("RoleName") });

    public async Task<string?> RegisterUserAsync(RegisterUserViewModel model)
    {
        using var connection = _factory.CreateConnection();
        await connection.OpenAsync();

        var roleName = await GetRoleNameAsync(connection, model.RoleID);
        if (string.IsNullOrWhiteSpace(roleName))
        {
            return "Selected role is invalid.";
        }

        var employeeId = roleName == "Employee" ? model.EmployeeID : null;
        if (roleName == "Employee" && !employeeId.HasValue)
        {
            return "Employee account must be linked with an employee record.";
        }

        if (await UsernameExistsAsync(connection, model.Username))
        {
            return "This username already exists. Please choose another username.";
        }

        if (employeeId.HasValue && await EmployeeLoginExistsAsync(connection, employeeId.Value))
        {
            return "This employee already has a login account.";
        }

        using var command = new SqlCommand("""
            INSERT INTO Users(Username, Password, RoleID, EmployeeID, IsActive)
            VALUES(@Username, @Password, @RoleID, @EmployeeID, 1)
            """, connection);
        command.Parameters.AddWithValue("@Username", model.Username.Trim());
        command.Parameters.AddWithValue("@Password", model.Password);
        command.Parameters.AddWithValue("@RoleID", model.RoleID);
        command.Parameters.AddWithValue("@EmployeeID", employeeId.HasValue ? employeeId.Value : DBNull.Value);
        await command.ExecuteNonQueryAsync();

        return null;
    }

    public async Task<List<Employee>> GetEmployeesAsync(int? take = null)
    {
        var sql = $"""
            SELECT {(take.HasValue ? $"TOP ({take.Value})" : "")}
                e.EmployeeID, e.EmployeeCode, e.FullName, e.FatherName, e.Gender, e.CNIC, e.Phone, e.Email,
                e.Address, e.DepartmentID, e.DesignationID, e.JoiningDate, e.BasicSalary, e.IsActive,
                ISNULL(d.DepartmentName, '') DepartmentName, ISNULL(ds.DesignationName, '') DesignationName
            FROM Employees e
            LEFT JOIN Departments d ON e.DepartmentID = d.DepartmentID
            LEFT JOIN Designations ds ON e.DesignationID = ds.DesignationID
            ORDER BY e.EmployeeID ASC
            """;

        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand(sql, connection);
        await connection.OpenAsync();
        using var reader = await command.ExecuteReaderAsync();
        var employees = new List<Employee>();
        while (await reader.ReadAsync())
        {
            employees.Add(MapEmployee(reader));
        }
        return employees;
    }

    public async Task<Employee?> GetEmployeeAsync(int id)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("""
            SELECT e.*, ISNULL(d.DepartmentName, '') DepartmentName, ISNULL(ds.DesignationName, '') DesignationName
            FROM Employees e
            LEFT JOIN Departments d ON e.DepartmentID = d.DepartmentID
            LEFT JOIN Designations ds ON e.DesignationID = ds.DesignationID
            WHERE e.EmployeeID = @EmployeeID
            """, connection);
        command.Parameters.AddWithValue("@EmployeeID", id);
        await connection.OpenAsync();
        using var reader = await command.ExecuteReaderAsync();
        return await reader.ReadAsync() ? MapEmployee(reader) : null;
    }

    public async Task SaveEmployeeAsync(Employee employee)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand(employee.EmployeeID == 0
            ? """
              INSERT INTO Employees(EmployeeCode, FullName, FatherName, Gender, CNIC, Phone, Email, Address, DepartmentID, DesignationID, JoiningDate, BasicSalary, IsActive)
              VALUES(@EmployeeCode, @FullName, @FatherName, @Gender, @CNIC, @Phone, @Email, @Address, @DepartmentID, @DesignationID, @JoiningDate, @BasicSalary, @IsActive)
              """
            : """
              UPDATE Employees SET EmployeeCode=@EmployeeCode, FullName=@FullName, FatherName=@FatherName, Gender=@Gender, CNIC=@CNIC,
                  Phone=@Phone, Email=@Email, Address=@Address, DepartmentID=@DepartmentID, DesignationID=@DesignationID,
                  JoiningDate=@JoiningDate, BasicSalary=@BasicSalary, IsActive=@IsActive
              WHERE EmployeeID=@EmployeeID
              """, connection);
        command.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);
        command.Parameters.AddWithValue("@EmployeeCode", employee.EmployeeCode);
        command.Parameters.AddWithValue("@FullName", employee.FullName);
        command.Parameters.AddWithValue("@FatherName", DbValue(employee.FatherName));
        command.Parameters.AddWithValue("@Gender", DbValue(employee.Gender));
        command.Parameters.AddWithValue("@CNIC", DbValue(employee.CNIC));
        command.Parameters.AddWithValue("@Phone", DbValue(employee.Phone));
        command.Parameters.AddWithValue("@Email", DbValue(employee.Email));
        command.Parameters.AddWithValue("@Address", DbValue(employee.Address));
        command.Parameters.AddWithValue("@DepartmentID", DbValue(employee.DepartmentID));
        command.Parameters.AddWithValue("@DesignationID", DbValue(employee.DesignationID));
        command.Parameters.AddWithValue("@JoiningDate", DbValue(employee.JoiningDate));
        command.Parameters.AddWithValue("@BasicSalary", employee.BasicSalary);
        command.Parameters.AddWithValue("@IsActive", employee.IsActive);
        await connection.OpenAsync();
        await command.ExecuteNonQueryAsync();
    }

    public async Task DeleteEmployeeAsync(int id)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("UPDATE Employees SET IsActive = 0 WHERE EmployeeID = @EmployeeID", connection);
        command.Parameters.AddWithValue("@EmployeeID", id);
        await connection.OpenAsync();
        await command.ExecuteNonQueryAsync();
    }

    public Task<List<Department>> GetDepartmentsAsync() =>
        QueryAsync("SELECT DepartmentID, DepartmentName FROM Departments ORDER BY DepartmentName",
            reader => new Department { DepartmentID = reader.GetInt("DepartmentID"), DepartmentName = reader.GetText("DepartmentName") });

    public Task<List<Designation>> GetDesignationsAsync() =>
        QueryAsync("SELECT DesignationID, DesignationName FROM Designations ORDER BY DesignationName",
            reader => new Designation { DesignationID = reader.GetInt("DesignationID"), DesignationName = reader.GetText("DesignationName") });

    public async Task<List<SelectOption>> GetEmployeeOptionsAsync()
    {
        var employees = await GetEmployeesAsync();
        return employees.Where(e => e.IsActive)
            .Select(e => new SelectOption { Id = e.EmployeeID, Name = $"{e.EmployeeCode} - {e.FullName}" })
            .ToList();
    }

    public Task<List<DashboardAttendanceItem>> GetDashboardAttendanceAsync() =>
        QueryAsync("""
            SELECT e.FullName EmployeeName,
                   CASE WHEN a.Status = 'Present' THEN 'Present' ELSE 'Absent' END Status
            FROM Employees e
            LEFT JOIN Attendance a ON e.EmployeeID = a.EmployeeID
                AND a.AttendanceDate = CAST(GETDATE() AS DATE)
            WHERE e.IsActive = 1
            ORDER BY e.EmployeeID ASC
            """, reader => new DashboardAttendanceItem
        {
            EmployeeName = reader.GetText("EmployeeName"),
            Status = reader.GetText("Status")
        });

    public Task<List<AttendanceRecord>> GetAttendanceAsync(int? employeeId = null) =>
        QueryAsync($"""
            SELECT a.*, e.FullName EmployeeName
            FROM Attendance a
            JOIN Employees e ON a.EmployeeID = e.EmployeeID
            {(employeeId.HasValue ? "WHERE a.EmployeeID = @EmployeeID" : "")}
            ORDER BY a.AttendanceDate DESC, a.AttendanceID DESC
            """, reader => new AttendanceRecord
        {
            AttendanceID = reader.GetInt("AttendanceID"),
            EmployeeID = reader.GetInt("EmployeeID"),
            EmployeeName = reader.GetText("EmployeeName"),
            AttendanceDate = reader.GetDate("AttendanceDate") ?? DateTime.Today,
            Status = reader.GetText("Status"),
            CheckIn = reader.GetTime("CheckIn"),
            CheckOut = reader.GetTime("CheckOut")
        }, employeeId.HasValue ? [new SqlParameter("@EmployeeID", employeeId.Value)] : []);

    public async Task AddAttendanceAsync(AttendanceRecord attendance)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("""
            IF EXISTS (SELECT 1 FROM Attendance WHERE EmployeeID = @EmployeeID AND AttendanceDate = @AttendanceDate)
            BEGIN
                UPDATE Attendance
                SET Status = @Status, CheckIn = @CheckIn, CheckOut = @CheckOut
                WHERE EmployeeID = @EmployeeID AND AttendanceDate = @AttendanceDate
            END
            ELSE
            BEGIN
                INSERT INTO Attendance(EmployeeID, AttendanceDate, Status, CheckIn, CheckOut)
                VALUES(@EmployeeID, @AttendanceDate, @Status, @CheckIn, @CheckOut)
            END
            """, connection);
        command.Parameters.AddWithValue("@EmployeeID", attendance.EmployeeID);
        command.Parameters.AddWithValue("@AttendanceDate", attendance.AttendanceDate);
        command.Parameters.AddWithValue("@Status", attendance.Status);
        command.Parameters.AddWithValue("@CheckIn", DbValue(attendance.CheckIn));
        command.Parameters.AddWithValue("@CheckOut", DbValue(attendance.CheckOut));
        await connection.OpenAsync();
        await command.ExecuteNonQueryAsync();
    }

    public async Task MarkEmployeeCheckInAsync(int employeeId)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("""
            IF EXISTS (SELECT 1 FROM Attendance WHERE EmployeeID = @EmployeeID AND AttendanceDate = CAST(GETDATE() AS DATE))
            BEGIN
                UPDATE Attendance
                SET Status = 'Present',
                    CheckIn = ISNULL(CheckIn, CAST(GETDATE() AS TIME(0)))
                WHERE EmployeeID = @EmployeeID AND AttendanceDate = CAST(GETDATE() AS DATE)
            END
            ELSE
            BEGIN
                INSERT INTO Attendance(EmployeeID, AttendanceDate, Status, CheckIn)
                VALUES(@EmployeeID, CAST(GETDATE() AS DATE), 'Present', CAST(GETDATE() AS TIME(0)))
            END
            """, connection);
        command.Parameters.AddWithValue("@EmployeeID", employeeId);
        await connection.OpenAsync();
        await command.ExecuteNonQueryAsync();
    }

    public async Task MarkEmployeeCheckOutAsync(int employeeId)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("""
            IF EXISTS (SELECT 1 FROM Attendance WHERE EmployeeID = @EmployeeID AND AttendanceDate = CAST(GETDATE() AS DATE))
            BEGIN
                UPDATE Attendance
                SET Status = 'Present',
                    CheckOut = CAST(GETDATE() AS TIME(0))
                WHERE EmployeeID = @EmployeeID AND AttendanceDate = CAST(GETDATE() AS DATE)
            END
            ELSE
            BEGIN
                INSERT INTO Attendance(EmployeeID, AttendanceDate, Status, CheckOut)
                VALUES(@EmployeeID, CAST(GETDATE() AS DATE), 'Present', CAST(GETDATE() AS TIME(0)))
            END
            """, connection);
        command.Parameters.AddWithValue("@EmployeeID", employeeId);
        await connection.OpenAsync();
        await command.ExecuteNonQueryAsync();
    }

    public Task<List<LeaveRecord>> GetLeavesAsync(int? employeeId = null) =>
        QueryAsync($"""
            SELECT l.*, e.FullName EmployeeName
            FROM Leaves l
            JOIN Employees e ON l.EmployeeID = e.EmployeeID
            {(employeeId.HasValue ? "WHERE l.EmployeeID = @EmployeeID" : "")}
            ORDER BY l.LeaveID DESC
            """, reader => new LeaveRecord
        {
            LeaveID = reader.GetInt("LeaveID"),
            EmployeeID = reader.GetInt("EmployeeID"),
            EmployeeName = reader.GetText("EmployeeName"),
            LeaveType = reader.GetText("LeaveType"),
            StartDate = reader.GetDate("StartDate"),
            EndDate = reader.GetDate("EndDate"),
            Reason = reader.GetText("Reason"),
            Status = reader.GetText("Status")
        }, employeeId.HasValue ? [new SqlParameter("@EmployeeID", employeeId.Value)] : []);

    public async Task AddLeaveAsync(LeaveRecord leave)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("""
            INSERT INTO Leaves(EmployeeID, LeaveType, StartDate, EndDate, Reason, Status)
            VALUES(@EmployeeID, @LeaveType, @StartDate, @EndDate, @Reason, @Status)
            """, connection);
        command.Parameters.AddWithValue("@EmployeeID", leave.EmployeeID);
        command.Parameters.AddWithValue("@LeaveType", leave.LeaveType);
        command.Parameters.AddWithValue("@StartDate", DbValue(leave.StartDate));
        command.Parameters.AddWithValue("@EndDate", DbValue(leave.EndDate));
        command.Parameters.AddWithValue("@Reason", DbValue(leave.Reason));
        command.Parameters.AddWithValue("@Status", leave.Status);
        await connection.OpenAsync();
        await command.ExecuteNonQueryAsync();
    }

    public async Task UpdateLeaveStatusAsync(int leaveId, string status)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("UPDATE Leaves SET Status = @Status WHERE LeaveID = @LeaveID", connection);
        command.Parameters.AddWithValue("@LeaveID", leaveId);
        command.Parameters.AddWithValue("@Status", status);
        await connection.OpenAsync();
        await command.ExecuteNonQueryAsync();
    }

    public async Task<List<Payroll>> GetPayrollsAsync(int? take = null, int? employeeId = null)
    {
        var sql = $"""
            SELECT {(take.HasValue ? $"TOP ({take.Value})" : "")} p.*, e.FullName EmployeeName
            FROM Payroll p
            JOIN Employees e ON p.EmployeeID = e.EmployeeID
            {(employeeId.HasValue ? "WHERE p.EmployeeID = @EmployeeID" : "")}
            ORDER BY p.PayrollDate DESC, p.PayrollID DESC
            """;
        return await QueryAsync(sql, MapPayroll, employeeId.HasValue ? [new SqlParameter("@EmployeeID", employeeId.Value)] : []);
    }

    public async Task<Payroll?> GetPayrollAsync(int id)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand("""
            SELECT p.*, e.FullName EmployeeName
            FROM Payroll p
            JOIN Employees e ON p.EmployeeID = e.EmployeeID
            WHERE p.PayrollID = @PayrollID
            """, connection);
        command.Parameters.AddWithValue("@PayrollID", id);
        await connection.OpenAsync();
        using var reader = await command.ExecuteReaderAsync();
        return await reader.ReadAsync() ? MapPayroll(reader) : null;
    }

    public Task<List<PayrollDetail>> GetPayrollDetailsAsync(int payrollId) =>
        QueryAsync("""
            SELECT pd.DetailID, pd.PayrollID, pd.Description, pd.Allowance, pd.Amount, pd.Type
            FROM PayrollDetails pd
            WHERE pd.PayrollID = @PayrollID
            ORDER BY pd.DetailID
            """,
            reader => new PayrollDetail
            {
                DetailID = reader.GetInt("DetailID"),
                PayrollID = reader.GetInt("PayrollID"),
                Description = reader.GetText("Description"),
                Allowance = reader.GetMoney("Allowance"),
                Amount = reader.GetMoney("Amount"),
                Type = reader.GetText("Type")
            },
            new SqlParameter("@PayrollID", payrollId));

    public async Task<int> GeneratePayrollAsync(int employeeId, int month, int year, decimal allowance, string allowanceType)
    {
        var employee = await GetEmployeeAsync(employeeId) ?? throw new InvalidOperationException("Employee not found.");
        allowanceType = string.IsNullOrWhiteSpace(allowanceType) ? "Allowance" : allowanceType;
        var totalAllowance = allowance;
        var netSalary = employee.BasicSalary + totalAllowance;

        using var connection = _factory.CreateConnection();
        await connection.OpenAsync();
        using var transaction = connection.BeginTransaction();
        try
        {
            using var insertPayroll = new SqlCommand("""
                INSERT INTO Payroll(EmployeeID, PayrollMonth, PayrollYear, BasicSalary, TotalAllowance, NetSalary, PayrollDate)
                OUTPUT INSERTED.PayrollID
                VALUES(@EmployeeID, @PayrollMonth, @PayrollYear, @BasicSalary, @TotalAllowance, @NetSalary, @PayrollDate)
                """, connection, transaction);
            insertPayroll.Parameters.AddWithValue("@EmployeeID", employeeId);
            insertPayroll.Parameters.AddWithValue("@PayrollMonth", month);
            insertPayroll.Parameters.AddWithValue("@PayrollYear", year);
            insertPayroll.Parameters.AddWithValue("@BasicSalary", employee.BasicSalary);
            insertPayroll.Parameters.AddWithValue("@TotalAllowance", totalAllowance);
            insertPayroll.Parameters.AddWithValue("@NetSalary", netSalary);
            insertPayroll.Parameters.AddWithValue("@PayrollDate", DateTime.Today);
            var payrollId = Convert.ToInt32(await insertPayroll.ExecuteScalarAsync());

            await InsertPayrollDetailAsync(connection, transaction, payrollId, "Basic Salary", employee.BasicSalary, "Earning");
            if (totalAllowance > 0)
            {
                await InsertPayrollDetailAsync(connection, transaction, payrollId, "Allowance", totalAllowance, allowanceType, totalAllowance);
            }

            var previousGeneralBalance = await GetLastGeneralLedgerBalanceAsync(connection, transaction);
            var newGeneralBalance = previousGeneralBalance - netSalary;
            await InsertGeneralLedgerEntryAsync(
                connection,
                transaction,
                payrollId,
                employeeId,
                DateTime.Today,
                $"Salary paid to {employee.FullName} for {month}/{year}",
                netSalary,
                0,
                newGeneralBalance);

            transaction.Commit();
            return payrollId;
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    public Task<List<AccountEntry>> GetAccountsAsync(string? employeeLedgerId = null)
    {
        var employeeFilter = string.IsNullOrWhiteSpace(employeeLedgerId) ? null : employeeLedgerId.Trim();
        return QueryAsync("""
            SELECT gl.GeneralLedgerID AccountID, gl.PayrollID, gl.EmployeeID, e.EmployeeCode, e.FullName EmployeeName,
                   gl.TransactionDate, gl.Description, gl.Debit, gl.Credit, gl.Balance
            FROM GeneralLedger gl
            LEFT JOIN Employees e ON gl.EmployeeID = e.EmployeeID
            WHERE @EmployeeLedgerId IS NULL
               OR CAST(gl.EmployeeID AS VARCHAR(20)) = @EmployeeLedgerId
               OR e.EmployeeCode = @EmployeeLedgerId
            ORDER BY gl.TransactionDate DESC, gl.GeneralLedgerID DESC
            """,
            reader => new AccountEntry
            {
                AccountID = reader.GetInt("AccountID"),
                PayrollID = reader["PayrollID"] == DBNull.Value ? null : reader.GetInt("PayrollID"),
                EmployeeID = reader["EmployeeID"] == DBNull.Value ? null : reader.GetInt("EmployeeID"),
                EmployeeCode = reader.GetText("EmployeeCode"),
                EmployeeName = reader.GetText("EmployeeName"),
                TransactionDate = reader.GetDate("TransactionDate"),
                Description = reader.GetText("Description"),
                Debit = reader.GetMoney("Debit"),
                Credit = reader.GetMoney("Credit"),
                Balance = reader.GetMoney("Balance")
            },
            new SqlParameter("@EmployeeLedgerId", DbValue(employeeFilter)));
    }

    public Task<List<EmployeeLedgerEntry>> GetEmployeeLedgerAsync(string? employeeLedgerId = null)
    {
        var employeeFilter = string.IsNullOrWhiteSpace(employeeLedgerId) ? null : employeeLedgerId.Trim();
        return QueryAsync("""
            SELECT gl.GeneralLedgerID EmployeeLedgerID, gl.EmployeeID, e.EmployeeCode, e.FullName EmployeeName, gl.PayrollID,
                   COALESCE(NULLIF(pd.Type, 'Earning'), '') AllowanceType,
                   gl.TransactionDate, gl.Description, gl.Debit, gl.Credit, gl.Balance
            FROM GeneralLedger gl
            JOIN Employees e ON gl.EmployeeID = e.EmployeeID
            OUTER APPLY
            (
                SELECT TOP 1 Type
                FROM PayrollDetails pd
                WHERE pd.PayrollID = gl.PayrollID AND pd.Type <> 'Earning'
                ORDER BY pd.DetailID DESC
            ) pd
            WHERE @EmployeeLedgerId IS NULL
               OR CAST(gl.EmployeeID AS VARCHAR(20)) = @EmployeeLedgerId
               OR e.EmployeeCode = @EmployeeLedgerId
            ORDER BY gl.TransactionDate DESC, gl.GeneralLedgerID DESC
            """,
            reader => new EmployeeLedgerEntry
            {
                EmployeeLedgerID = reader.GetInt("EmployeeLedgerID"),
                EmployeeID = reader.GetInt("EmployeeID"),
                EmployeeCode = reader.GetText("EmployeeCode"),
                EmployeeName = reader.GetText("EmployeeName"),
                PayrollID = reader["PayrollID"] == DBNull.Value ? null : reader.GetInt("PayrollID"),
                AllowanceType = reader.GetText("AllowanceType"),
                TransactionDate = reader.GetDate("TransactionDate") ?? DateTime.Today,
                Description = reader.GetText("Description"),
                Debit = reader.GetMoney("Debit"),
                Credit = reader.GetMoney("Credit"),
                Balance = reader.GetMoney("Balance")
            },
            new SqlParameter("@EmployeeLedgerId", DbValue(employeeFilter)));
    }

    private async Task<int> CountAsync(string table, string? where = null, params SqlParameter[] parameters)
    {
        var sql = $"SELECT COUNT(*) FROM {table}" + (string.IsNullOrWhiteSpace(where) ? "" : $" WHERE {where}");
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand(sql, connection);
        command.Parameters.AddRange(parameters);
        await connection.OpenAsync();
        return Convert.ToInt32(await command.ExecuteScalarAsync());
    }

    private async Task<decimal> ScalarMoneyAsync(string sql, params SqlParameter[] parameters)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand(sql, connection);
        command.Parameters.AddRange(parameters);
        await connection.OpenAsync();
        return Convert.ToDecimal(await command.ExecuteScalarAsync());
    }

    private async Task<List<T>> QueryAsync<T>(string sql, Func<SqlDataReader, T> map, params SqlParameter[] parameters)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand(sql, connection);
        command.Parameters.AddRange(parameters);
        await connection.OpenAsync();
        using var reader = await command.ExecuteReaderAsync();
        var rows = new List<T>();
        while (await reader.ReadAsync())
        {
            rows.Add(map(reader));
        }
        return rows;
    }

    private static async Task<string?> GetRoleNameAsync(SqlConnection connection, int roleId)
    {
        using var command = new SqlCommand("SELECT RoleName FROM Roles WHERE RoleID = @RoleID", connection);
        command.Parameters.AddWithValue("@RoleID", roleId);
        var result = await command.ExecuteScalarAsync();
        return result == null || result == DBNull.Value ? null : Convert.ToString(result);
    }

    private static async Task<bool> UsernameExistsAsync(SqlConnection connection, string username)
    {
        using var command = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @Username", connection);
        command.Parameters.AddWithValue("@Username", username.Trim());
        return Convert.ToInt32(await command.ExecuteScalarAsync()) > 0;
    }

    private static async Task<bool> EmployeeLoginExistsAsync(SqlConnection connection, int employeeId)
    {
        using var command = new SqlCommand("""
            SELECT COUNT(*)
            FROM Users u
            JOIN Roles r ON u.RoleID = r.RoleID
            WHERE u.EmployeeID = @EmployeeID AND r.RoleName = 'Employee'
            """, connection);
        command.Parameters.AddWithValue("@EmployeeID", employeeId);
        return Convert.ToInt32(await command.ExecuteScalarAsync()) > 0;
    }

    private async Task<List<T>> QueryMoneyItemsAsync<T>(string table, string idColumn, string nameColumn, Func<SqlDataReader, T> map)
    {
        return await QueryAsync($"""
            SELECT m.{idColumn}, m.EmployeeID, e.FullName EmployeeName, m.{nameColumn}, m.Amount
            FROM {table} m
            JOIN Employees e ON m.EmployeeID = e.EmployeeID
            ORDER BY m.{idColumn} DESC
            """, map);
    }

    private async Task AddMoneyItemAsync(string table, string nameColumn, int employeeId, string name, decimal amount)
    {
        using var connection = _factory.CreateConnection();
        using var command = new SqlCommand($"INSERT INTO {table}(EmployeeID, {nameColumn}, Amount) VALUES(@EmployeeID, @Name, @Amount)", connection);
        command.Parameters.AddWithValue("@EmployeeID", employeeId);
        command.Parameters.AddWithValue("@Name", name);
        command.Parameters.AddWithValue("@Amount", amount);
        await connection.OpenAsync();
        await command.ExecuteNonQueryAsync();
    }

    private static async Task InsertPayrollDetailAsync(SqlConnection connection, SqlTransaction transaction, int payrollId, string description, decimal amount, string type, decimal allowance = 0)
    {
        using var command = new SqlCommand("""
            INSERT INTO PayrollDetails(PayrollID, Description, Allowance, Amount, Type)
            VALUES(@PayrollID, @Description, @Allowance, @Amount, @Type)
            """, connection, transaction);
        command.Parameters.AddWithValue("@PayrollID", payrollId);
        command.Parameters.AddWithValue("@Description", description);
        command.Parameters.AddWithValue("@Allowance", allowance);
        command.Parameters.AddWithValue("@Amount", amount);
        command.Parameters.AddWithValue("@Type", type);
        await command.ExecuteNonQueryAsync();
    }

    private static async Task<decimal> GetLastGeneralLedgerBalanceAsync(SqlConnection connection, SqlTransaction transaction)
    {
        using var command = new SqlCommand("SELECT TOP 1 Balance FROM GeneralLedger ORDER BY GeneralLedgerID DESC", connection, transaction);
        var result = await command.ExecuteScalarAsync();
        return result == null || result == DBNull.Value ? 0 : Convert.ToDecimal(result);
    }

    private static async Task InsertGeneralLedgerEntryAsync(SqlConnection connection, SqlTransaction transaction, int payrollId, int? employeeId, DateTime transactionDate, string description, decimal debit, decimal credit, decimal balance)
    {
        using var command = new SqlCommand("""
            INSERT INTO GeneralLedger(PayrollID, EmployeeID, TransactionDate, Description, Debit, Credit, Balance)
            VALUES(@PayrollID, @EmployeeID, @TransactionDate, @Description, @Debit, @Credit, @Balance)
            """, connection, transaction);
        command.Parameters.AddWithValue("@PayrollID", payrollId);
        command.Parameters.AddWithValue("@EmployeeID", DbValue(employeeId));
        command.Parameters.AddWithValue("@TransactionDate", transactionDate);
        command.Parameters.AddWithValue("@Description", description);
        command.Parameters.AddWithValue("@Debit", debit);
        command.Parameters.AddWithValue("@Credit", credit);
        command.Parameters.AddWithValue("@Balance", balance);
        await command.ExecuteNonQueryAsync();
    }

    private static Employee MapEmployee(SqlDataReader reader) => new()
    {
        EmployeeID = reader.GetInt("EmployeeID"),
        EmployeeCode = reader.GetText("EmployeeCode"),
        FullName = reader.GetText("FullName"),
        FatherName = reader.GetText("FatherName"),
        Gender = reader.GetText("Gender"),
        CNIC = reader.GetText("CNIC"),
        Phone = reader.GetText("Phone"),
        Email = reader.GetText("Email"),
        Address = reader.GetText("Address"),
        DepartmentID = reader["DepartmentID"] == DBNull.Value ? null : reader.GetInt("DepartmentID"),
        DesignationID = reader["DesignationID"] == DBNull.Value ? null : reader.GetInt("DesignationID"),
        JoiningDate = reader.GetDate("JoiningDate"),
        BasicSalary = reader.GetMoney("BasicSalary"),
        IsActive = reader.GetBool("IsActive"),
        DepartmentName = reader.GetText("DepartmentName"),
        DesignationName = reader.GetText("DesignationName")
    };

    private static Payroll MapPayroll(SqlDataReader reader) => new()
    {
        PayrollID = reader.GetInt("PayrollID"),
        EmployeeID = reader.GetInt("EmployeeID"),
        EmployeeName = reader.GetText("EmployeeName"),
        PayrollMonth = reader.GetInt("PayrollMonth"),
        PayrollYear = reader.GetInt("PayrollYear"),
        BasicSalary = reader.GetMoney("BasicSalary"),
        TotalAllowance = reader.GetMoney("TotalAllowance"),
        NetSalary = reader.GetMoney("NetSalary"),
        PayrollDate = reader.GetDate("PayrollDate") ?? DateTime.Today
    };

    private static object DbValue<T>(T? value) => value is null ? DBNull.Value : value;
}
