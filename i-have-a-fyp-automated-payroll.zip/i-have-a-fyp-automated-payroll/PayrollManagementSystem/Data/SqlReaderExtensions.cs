using Microsoft.Data.SqlClient;

namespace PayrollManagementSystem.Data;

public static class SqlReaderExtensions
{
    public static int GetInt(this SqlDataReader reader, string name) =>
        reader[name] == DBNull.Value ? 0 : Convert.ToInt32(reader[name]);

    public static string GetText(this SqlDataReader reader, string name) =>
        reader[name] == DBNull.Value ? string.Empty : Convert.ToString(reader[name]) ?? string.Empty;

    public static decimal GetMoney(this SqlDataReader reader, string name) =>
        reader[name] == DBNull.Value ? 0 : Convert.ToDecimal(reader[name]);

    public static bool GetBool(this SqlDataReader reader, string name) =>
        reader[name] != DBNull.Value && Convert.ToBoolean(reader[name]);

    public static DateTime? GetDate(this SqlDataReader reader, string name) =>
        reader[name] == DBNull.Value ? null : Convert.ToDateTime(reader[name]);

    public static TimeSpan? GetTime(this SqlDataReader reader, string name) =>
        reader[name] == DBNull.Value ? null : (TimeSpan)reader[name];
}
