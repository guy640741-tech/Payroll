using Microsoft.Data.SqlClient;
using System.Text.RegularExpressions;

namespace PayrollManagementSystem.Data;

public sealed class DatabaseInitializer
{
    private readonly IConfiguration _configuration;
    private readonly IWebHostEnvironment _environment;

    public DatabaseInitializer(IConfiguration configuration, IWebHostEnvironment environment)
    {
        _configuration = configuration;
        _environment = environment;
    }

    public async Task EnsureCreatedAsync()
    {
        var connectionString = _configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("DefaultConnection is missing.");
        var builder = new SqlConnectionStringBuilder(connectionString);
        var databaseName = builder.InitialCatalog;
        builder.InitialCatalog = "master";

        await using var connection = new SqlConnection(builder.ConnectionString);
        await connection.OpenAsync();

        await using (var checkCommand = new SqlCommand("SELECT DB_ID(@DatabaseName)", connection))
        {
            checkCommand.Parameters.AddWithValue("@DatabaseName", databaseName);
            if (await checkCommand.ExecuteScalarAsync() != DBNull.Value)
            {
                return;
            }
        }

        var scriptPath = Path.Combine(_environment.ContentRootPath, "Database", "PayrollManagementSystemDB.sql");
        var script = await File.ReadAllTextAsync(scriptPath);
        var batches = Regex.Split(script, @"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);

        foreach (var batch in batches.Where(b => !string.IsNullOrWhiteSpace(b)))
        {
            await using var command = new SqlCommand(batch, connection);
            await command.ExecuteNonQueryAsync();
        }

        await SeedDemoUsersAsync(connection);
    }

    public async Task EnsureDemoUsersAsync()
    {
        var connectionString = _configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("DefaultConnection is missing.");
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync();
        await EnsureSchemaUpdatesAsync(connection);
        await SeedDemoUsersAsync(connection);
    }

    private static async Task EnsureSchemaUpdatesAsync(SqlConnection connection)
    {
        var statements = new[]
        {
            """
            IF OBJECT_ID('PayrollAllowances', 'U') IS NOT NULL
            BEGIN
                DROP TABLE PayrollAllowances
            END
            """,
            """
            IF OBJECT_ID('EmployeeAllowances', 'U') IS NOT NULL
            BEGIN
                DROP TABLE EmployeeAllowances
            END
            """,
            """
            IF OBJECT_ID('Allowances', 'U') IS NOT NULL
            BEGIN
                DROP TABLE Allowances
            END
            """,
            """
            IF OBJECT_ID('AllowanceTypes', 'U') IS NOT NULL
            BEGIN
                DROP TABLE AllowanceTypes
            END
            """,
            """
            IF COL_LENGTH('PayrollDetails', 'Allowance') IS NULL
            BEGIN
                ALTER TABLE PayrollDetails ADD Allowance DECIMAL(18,2) DEFAULT 0
            END
            """,
            """
            IF OBJECT_ID('GeneralLedger', 'U') IS NOT NULL
               AND COL_LENGTH('GeneralLedger', 'EmployeeID') IS NULL
            BEGIN
                ALTER TABLE GeneralLedger ADD EmployeeID INT NULL
            END
            """,
            """
            IF OBJECT_ID('GeneralLedger', 'U') IS NULL
            BEGIN
                CREATE TABLE GeneralLedger
                (
                    GeneralLedgerID INT IDENTITY(1,1) PRIMARY KEY,
                    PayrollID INT NULL,
                    EmployeeID INT NULL,
                    TransactionDate DATE NOT NULL,
                    Description VARCHAR(255),
                    Debit DECIMAL(18,2) DEFAULT 0,
                    Credit DECIMAL(18,2) DEFAULT 0,
                    Balance DECIMAL(18,2) DEFAULT 0,
                    FOREIGN KEY(PayrollID) REFERENCES Payroll(PayrollID),
                    FOREIGN KEY(EmployeeID) REFERENCES Employees(EmployeeID)
                )
            END
            """,
            """
            IF OBJECT_ID('EmployeeLedger', 'U') IS NOT NULL
            BEGIN
                INSERT INTO GeneralLedger(PayrollID, EmployeeID, TransactionDate, Description, Debit, Credit, Balance)
                SELECT el.PayrollID, el.EmployeeID, el.TransactionDate, el.Description, el.Debit, el.Credit, el.Balance
                FROM EmployeeLedger el
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM GeneralLedger gl
                    WHERE ISNULL(gl.PayrollID, 0) = ISNULL(el.PayrollID, 0)
                      AND ISNULL(gl.EmployeeID, 0) = ISNULL(el.EmployeeID, 0)
                      AND gl.TransactionDate = el.TransactionDate
                      AND ISNULL(gl.Description, '') = ISNULL(el.Description, '')
                )

                DROP TABLE EmployeeLedger
            END
            """,
            """
            IF OBJECT_ID('Accounts', 'U') IS NOT NULL
               AND NOT EXISTS (SELECT 1 FROM GeneralLedger)
            BEGIN
                INSERT INTO GeneralLedger(TransactionDate, Description, Debit, Credit, Balance)
                SELECT TransactionDate, Description, Debit, Credit, Balance
                FROM Accounts
            END
            """,
            """
            IF OBJECT_ID('Deductions', 'U') IS NOT NULL
            BEGIN
                DROP TABLE Deductions
            END
            """
        };

        foreach (var statement in statements)
        {
            await using var command = new SqlCommand(statement, connection);
            await command.ExecuteNonQueryAsync();
        }
    }

    private static async Task SeedDemoUsersAsync(SqlConnection connection)
    {
        await using (var command = new SqlCommand("""
            IF COL_LENGTH('Users', 'EmployeeID') IS NULL
            BEGIN
                ALTER TABLE Users ADD EmployeeID INT NULL
            END
            """, connection))
        {
            await command.ExecuteNonQueryAsync();
        }

        await EnsureUserAsync(connection, "admin", "admin123", "Admin", null);
        await EnsureUserAsync(connection, "hr", "hr123", "HR", null);
        await EnsureUserAsync(connection, "accountant", "account123", "Accountant", null);
        await EnsureUserAsync(connection, "employee", "employee123", "Employee", 1);
    }

    private static async Task EnsureUserAsync(SqlConnection connection, string username, string password, string roleName, int? employeeId)
    {
        await using var command = new SqlCommand("""
            IF NOT EXISTS (SELECT 1 FROM Users WHERE Username = @Username)
            BEGIN
                INSERT INTO Users(Username, Password, RoleID, IsActive, EmployeeID)
                SELECT @Username, @Password, RoleID, 1, @EmployeeID
                FROM Roles
                WHERE RoleName = @RoleName
            END
            """, connection);
        command.Parameters.AddWithValue("@Username", username);
        command.Parameters.AddWithValue("@Password", password);
        command.Parameters.AddWithValue("@RoleName", roleName);
        command.Parameters.AddWithValue("@EmployeeID", employeeId.HasValue ? employeeId.Value : DBNull.Value);
        await command.ExecuteNonQueryAsync();
    }
}
