using Microsoft.Data.SqlClient;

namespace PayrollManagementSystem.Data;

public sealed class DatabaseConnectionFactory
{
    private readonly string _connectionString;

    public DatabaseConnectionFactory(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("DefaultConnection is missing.");
    }

    public SqlConnection CreateConnection() => new(_connectionString);
}
