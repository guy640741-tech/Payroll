using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using PayrollManagementSystem.Data;
using PayrollManagementSystem.Infrastructure;
using PayrollManagementSystem.Models;

namespace PayrollManagementSystem.Controllers;

[RoleAuthorize]
public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly PayrollRepository _repository;

    public HomeController(ILogger<HomeController> logger, PayrollRepository repository)
    {
        _logger = logger;
        _repository = repository;
    }

    public async Task<IActionResult> Index()
    {
        var role = HttpContext.Session.GetString("RoleName");
        var employeeId = role == "Employee" ? HttpContext.Session.GetInt32("EmployeeID") : null;
        ViewBag.RoleName = role;
        return View(await _repository.GetDashboardAsync(employeeId));
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
