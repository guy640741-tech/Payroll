using Microsoft.AspNetCore.Mvc;
using PayrollManagementSystem.Data;
using PayrollManagementSystem.Infrastructure;

namespace PayrollManagementSystem.Controllers;

[RoleAuthorize("Admin", "Accountant")]
public class AccountsController : Controller
{
    private readonly PayrollRepository _repository;

    public AccountsController(PayrollRepository repository) => _repository = repository;

    public async Task<IActionResult> Index(string? employeeLedgerId)
    {
        ViewBag.EmployeeLedgerId = employeeLedgerId;
        ViewBag.Employees = await _repository.GetEmployeeOptionsAsync();
        return View(await _repository.GetAccountsAsync(employeeLedgerId));
    }

    public async Task<IActionResult> EmployeeLedger(string? employeeLedgerId)
    {
        return RedirectToAction(nameof(Index), new { employeeLedgerId });
    }
}
