using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using PayrollManagementSystem.Data;
using PayrollManagementSystem.Infrastructure;
using PayrollManagementSystem.Models;

namespace PayrollManagementSystem.Controllers;

[RoleAuthorize("Admin", "HR")]
public class EmployeesController : Controller
{
    private readonly PayrollRepository _repository;

    public EmployeesController(PayrollRepository repository)
    {
        _repository = repository;
    }

    public async Task<IActionResult> Index() => View(await _repository.GetEmployeesAsync());

    public async Task<IActionResult> Create()
    {
        await LoadListsAsync();
        return View("Form", new Employee());
    }

    [HttpPost]
    public async Task<IActionResult> Create(Employee employee)
    {
        if (!ModelState.IsValid)
        {
            await LoadListsAsync();
            return View("Form", employee);
        }

        await _repository.SaveEmployeeAsync(employee);
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var employee = await _repository.GetEmployeeAsync(id);
        if (employee is null) return NotFound();
        await LoadListsAsync();
        return View("Form", employee);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(Employee employee)
    {
        if (!ModelState.IsValid)
        {
            await LoadListsAsync();
            return View("Form", employee);
        }

        await _repository.SaveEmployeeAsync(employee);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        await _repository.DeleteEmployeeAsync(id);
        return RedirectToAction(nameof(Index));
    }

    private async Task LoadListsAsync()
    {
        ViewBag.Departments = new SelectList(await _repository.GetDepartmentsAsync(), "DepartmentID", "DepartmentName");
        ViewBag.Designations = new SelectList(await _repository.GetDesignationsAsync(), "DesignationID", "DesignationName");
    }
}
