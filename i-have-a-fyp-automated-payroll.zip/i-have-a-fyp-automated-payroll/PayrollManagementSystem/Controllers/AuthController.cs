using Microsoft.AspNetCore.Mvc;
using PayrollManagementSystem.Data;
using PayrollManagementSystem.ViewModels;

namespace PayrollManagementSystem.Controllers;

public class AuthController : Controller
{
    private readonly PayrollRepository _repository;

    public AuthController(PayrollRepository repository)
    {
        _repository = repository;
    }

    public async Task<IActionResult> Access()
    {
        var roles = await _repository.GetRolesAsync();
        return View(roles);
    }

    public IActionResult Login(string? role)
    {
        if (string.IsNullOrWhiteSpace(role))
        {
            role = "Admin";
        }

        ViewBag.SelectedRole = role;
        return View();
    }

    public async Task<IActionResult> Register(string? role)
    {
        var model = new RegisterUserViewModel();
        await LoadRegisterListsAsync(model);

        if (!string.IsNullOrWhiteSpace(role))
        {
            var selectedRole = model.Roles.FirstOrDefault(r => string.Equals(r.RoleName, role, StringComparison.OrdinalIgnoreCase));
            if (selectedRole is not null)
            {
                model.RoleID = selectedRole.RoleID;
                model.RoleName = selectedRole.RoleName;
            }
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> Login(string username, string password, string? selectedRole)
    {
        var user = await _repository.ValidateLoginAsync(username, password);
        if (user is not null)
        {
            if (!string.IsNullOrWhiteSpace(selectedRole) &&
                !string.Equals(user.RoleName, selectedRole, StringComparison.OrdinalIgnoreCase))
            {
                ViewBag.SelectedRole = selectedRole;
                ViewBag.Error = $"This login belongs to {user.RoleName}, not {selectedRole}. Please choose the correct designation.";
                return View();
            }

            HttpContext.Session.SetInt32("UserID", user.UserID);
            HttpContext.Session.SetString("Username", user.Username);
            HttpContext.Session.SetString("RoleName", user.RoleName);
            if (user.EmployeeID.HasValue)
            {
                HttpContext.Session.SetInt32("EmployeeID", user.EmployeeID.Value);
            }

            return RedirectToAction("Index", "Home");
        }

        ViewBag.Error = "Invalid username or password.";
        ViewBag.SelectedRole = selectedRole;
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterUserViewModel model)
    {
        await LoadRegisterListsAsync(model);
        model.RoleName = model.Roles.FirstOrDefault(r => r.RoleID == model.RoleID)?.RoleName ?? string.Empty;

        if (model.RoleName == "Employee" && !model.EmployeeID.HasValue)
        {
            ModelState.AddModelError(nameof(model.EmployeeID), "Employee account must be linked with an employee record.");
        }

        if (model.RoleName != "Employee")
        {
            model.EmployeeID = null;
        }

        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var error = await _repository.RegisterUserAsync(model);
        if (error is not null)
        {
            ModelState.AddModelError(string.Empty, error);
            return View(model);
        }

        TempData["Success"] = "User account registered successfully. You can login now.";
        return RedirectToAction(nameof(Login), new { role = model.RoleName });
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction(nameof(Access));
    }

    public IActionResult AccessDenied() => View();

    private async Task LoadRegisterListsAsync(RegisterUserViewModel model)
    {
        model.Roles = await _repository.GetRolesAsync();
        model.Employees = await _repository.GetEmployeeOptionsAsync();
    }
}
