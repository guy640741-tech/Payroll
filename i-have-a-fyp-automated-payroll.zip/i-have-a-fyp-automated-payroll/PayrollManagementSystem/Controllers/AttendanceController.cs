using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using PayrollManagementSystem.Data;
using PayrollManagementSystem.Infrastructure;
using PayrollManagementSystem.Models;

namespace PayrollManagementSystem.Controllers;

[RoleAuthorize("Admin", "HR", "Employee")]
public class AttendanceController : Controller
{
    private readonly PayrollRepository _repository;

    public AttendanceController(PayrollRepository repository) => _repository = repository;

    public async Task<IActionResult> Index()
    {
        var role = HttpContext.Session.GetString("RoleName");
        var employeeId = role == "Employee" ? HttpContext.Session.GetInt32("EmployeeID") : null;
        ViewBag.RoleName = role;
        ViewBag.EmployeeID = employeeId;
        ViewBag.Employees = new SelectList(await _repository.GetEmployeeOptionsAsync(), "Id", "Name");
        ViewBag.NewAttendance = new AttendanceRecord();
        return View(await _repository.GetAttendanceAsync(employeeId));
    }

    [HttpPost]
    [RoleAuthorize("Admin", "HR")]
    public async Task<IActionResult> Create(AttendanceRecord attendance)
    {
        await _repository.AddAttendanceAsync(attendance);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [RoleAuthorize("Employee")]
    public async Task<IActionResult> CheckIn()
    {
        var employeeId = HttpContext.Session.GetInt32("EmployeeID");
        if (!employeeId.HasValue)
        {
            return RedirectToAction("AccessDenied", "Auth");
        }

        await _repository.MarkEmployeeCheckInAsync(employeeId.Value);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [RoleAuthorize("Employee")]
    public async Task<IActionResult> CheckOut()
    {
        var employeeId = HttpContext.Session.GetInt32("EmployeeID");
        if (!employeeId.HasValue)
        {
            return RedirectToAction("AccessDenied", "Auth");
        }

        await _repository.MarkEmployeeCheckOutAsync(employeeId.Value);
        return RedirectToAction(nameof(Index));
    }
}
