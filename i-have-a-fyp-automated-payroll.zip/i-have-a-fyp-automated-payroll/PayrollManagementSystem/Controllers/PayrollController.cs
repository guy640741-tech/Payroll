using Microsoft.AspNetCore.Mvc;
using PayrollManagementSystem.Data;
using PayrollManagementSystem.Infrastructure;
using PayrollManagementSystem.ViewModels;

namespace PayrollManagementSystem.Controllers;

[RoleAuthorize("Admin", "Accountant", "Employee")]
public class PayrollController : Controller
{
    private readonly PayrollRepository _repository;

    public PayrollController(PayrollRepository repository) => _repository = repository;

    public async Task<IActionResult> Index()
    {
        var role = HttpContext.Session.GetString("RoleName");
        var employeeId = role == "Employee" ? HttpContext.Session.GetInt32("EmployeeID") : null;
        ViewBag.RoleName = role;
        return View(await _repository.GetPayrollsAsync(employeeId: employeeId));
    }

    [RoleAuthorize("Admin", "Accountant")]
    public async Task<IActionResult> Generate()
    {
        return View(new PayrollGenerateViewModel { Employees = await _repository.GetEmployeeOptionsAsync() });
    }

    [HttpPost]
    [RoleAuthorize("Admin", "Accountant")]
    public async Task<IActionResult> Generate(PayrollGenerateViewModel model)
    {
        if (model.EmployeeID == 0)
        {
            model.Employees = await _repository.GetEmployeeOptionsAsync();
            ModelState.AddModelError("", "Please select an employee.");
            return View(model);
        }

        var payrollId = await _repository.GeneratePayrollAsync(model.EmployeeID, model.PayrollMonth, model.PayrollYear, model.Allowance, model.AllowanceType);
        return RedirectToAction(nameof(Payslip), new { id = payrollId });
    }

    public async Task<IActionResult> Payslip(int id)
    {
        var payroll = await _repository.GetPayrollAsync(id);
        if (payroll is null) return NotFound();
        if (HttpContext.Session.GetString("RoleName") == "Employee" &&
            HttpContext.Session.GetInt32("EmployeeID") != payroll.EmployeeID)
        {
            return RedirectToAction("AccessDenied", "Auth");
        }

        ViewBag.Details = await _repository.GetPayrollDetailsAsync(id);
        return View(payroll);
    }
}
