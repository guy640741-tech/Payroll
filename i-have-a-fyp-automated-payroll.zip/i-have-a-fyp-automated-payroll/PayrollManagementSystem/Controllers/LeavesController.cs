using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using PayrollManagementSystem.Data;
using PayrollManagementSystem.Infrastructure;
using PayrollManagementSystem.Models;

namespace PayrollManagementSystem.Controllers;

[RoleAuthorize("Admin", "HR", "Employee")]
public class LeavesController : Controller
{
    private readonly PayrollRepository _repository;

    public LeavesController(PayrollRepository repository) => _repository = repository;

    public async Task<IActionResult> Index()
    {
        var role = HttpContext.Session.GetString("RoleName");
        var employeeId = role == "Employee" ? HttpContext.Session.GetInt32("EmployeeID") : null;
        ViewBag.RoleName = role;
        ViewBag.EmployeeID = employeeId;
        ViewBag.Employees = new SelectList(await _repository.GetEmployeeOptionsAsync(), "Id", "Name");
        return View(await _repository.GetLeavesAsync(employeeId));
    }

    [HttpPost]
    public async Task<IActionResult> Create(LeaveRecord leave)
    {
        if (HttpContext.Session.GetString("RoleName") == "Employee")
        {
            var employeeId = HttpContext.Session.GetInt32("EmployeeID");
            if (!employeeId.HasValue)
            {
                return RedirectToAction("AccessDenied", "Auth");
            }

            leave.EmployeeID = employeeId.Value;
            leave.Status = "Pending";
        }

        await _repository.AddLeaveAsync(leave);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [RoleAuthorize("Admin", "HR")]
    public async Task<IActionResult> UpdateStatus(int id, string status)
    {
        if (status is not ("Approved" or "Rejected" or "Pending"))
        {
            return BadRequest();
        }

        await _repository.UpdateLeaveStatusAsync(id, status);
        return RedirectToAction(nameof(Index));
    }
}
