using System.ComponentModel.DataAnnotations;

namespace PayrollManagementSystem.Models;

public class AppUser
{
    public int UserID { get; set; }
    public string Username { get; set; } = string.Empty;
    public int RoleID { get; set; }
    public string RoleName { get; set; } = string.Empty;
    public int? EmployeeID { get; set; }
    public bool IsActive { get; set; }
}

public class Role
{
    public int RoleID { get; set; }
    public string RoleName { get; set; } = string.Empty;
}

public class Department
{
    public int DepartmentID { get; set; }
    [Required, StringLength(100)]
    public string DepartmentName { get; set; } = string.Empty;
}

public class Designation
{
    public int DesignationID { get; set; }
    [Required, StringLength(100)]
    public string DesignationName { get; set; } = string.Empty;
}

public class Employee
{
    public int EmployeeID { get; set; }
    [Required(ErrorMessage = "Employee code is required."), StringLength(20)]
    public string EmployeeCode { get; set; } = string.Empty;
    [Required(ErrorMessage = "Full name is required."), StringLength(100)]
    public string FullName { get; set; } = string.Empty;
    [Required(ErrorMessage = "Father name is required."), StringLength(100)]
    public string? FatherName { get; set; }
    [Required(ErrorMessage = "Gender is required."), StringLength(10)]
    public string? Gender { get; set; }
    [Required(ErrorMessage = "CNIC is required."), StringLength(20)]
    public string? CNIC { get; set; }
    [Required(ErrorMessage = "Phone number is required."), StringLength(20)]
    public string? Phone { get; set; }
    [Required(ErrorMessage = "Email address is required."), EmailAddress(ErrorMessage = "Enter a valid email address."), StringLength(100)]
    public string? Email { get; set; }
    [Required(ErrorMessage = "Address is required."), StringLength(255)]
    public string? Address { get; set; }
    [Required(ErrorMessage = "Department is required.")]
    public int? DepartmentID { get; set; }
    [Required(ErrorMessage = "Designation is required.")]
    public int? DesignationID { get; set; }
    [Required(ErrorMessage = "Joining date is required.")]
    public DateTime? JoiningDate { get; set; } = DateTime.Today;
    [Range(1, 999999999, ErrorMessage = "Basic salary is required.")]
    public decimal BasicSalary { get; set; }
    public bool IsActive { get; set; } = true;
    public string DepartmentName { get; set; } = string.Empty;
    public string DesignationName { get; set; } = string.Empty;
}

public class AttendanceRecord
{
    public int AttendanceID { get; set; }
    [Range(1, int.MaxValue, ErrorMessage = "Employee is required.")]
    public int EmployeeID { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    [Required(ErrorMessage = "Attendance date is required.")]
    public DateTime AttendanceDate { get; set; } = DateTime.Today;
    [Required(ErrorMessage = "Attendance status is required.")]
    public string Status { get; set; } = "Present";
    public TimeSpan? CheckIn { get; set; }
    public TimeSpan? CheckOut { get; set; }
}

public class LeaveRecord
{
    public int LeaveID { get; set; }
    [Range(1, int.MaxValue, ErrorMessage = "Employee is required.")]
    public int EmployeeID { get; set; }
    [Required(ErrorMessage = "Leave type is required.")]
    public string EmployeeName { get; set; } = string.Empty;
    [Required(ErrorMessage = "Leave type is required.")]
    public string LeaveType { get; set; } = string.Empty;
    [Required(ErrorMessage = "Start date is required.")]
    public DateTime? StartDate { get; set; }
    [Required(ErrorMessage = "End date is required.")]
    public DateTime? EndDate { get; set; }
    [Required(ErrorMessage = "Reason is required.")]
    public string Reason { get; set; } = string.Empty;
    [Required(ErrorMessage = "Status is required.")]
    public string Status { get; set; } = "Pending";
}

public class Payroll
{
    public int PayrollID { get; set; }
    public int EmployeeID { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    public int PayrollMonth { get; set; } = DateTime.Today.Month;
    public int PayrollYear { get; set; } = DateTime.Today.Year;
    public decimal BasicSalary { get; set; }
    public decimal TotalAllowance { get; set; }
    public decimal NetSalary { get; set; }
    public DateTime PayrollDate { get; set; } = DateTime.Today;
}

public class PayrollDetail
{
    public int DetailID { get; set; }
    public int PayrollID { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Allowance { get; set; }
    public decimal Amount { get; set; }
    public string Type { get; set; } = string.Empty;
}

public class AccountEntry
{
    public int AccountID { get; set; }
    public int? PayrollID { get; set; }
    public int? EmployeeID { get; set; }
    public string EmployeeCode { get; set; } = string.Empty;
    public string EmployeeName { get; set; } = string.Empty;
    public DateTime? TransactionDate { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Debit { get; set; }
    public decimal Credit { get; set; }
    public decimal Balance { get; set; }
}

public class EmployeeLedgerEntry
{
    public int EmployeeLedgerID { get; set; }
    public int EmployeeID { get; set; }
    public string EmployeeCode { get; set; } = string.Empty;
    public string EmployeeName { get; set; } = string.Empty;
    public int? PayrollID { get; set; }
    public string AllowanceType { get; set; } = string.Empty;
    public DateTime TransactionDate { get; set; }
    public string Description { get; set; } = string.Empty;
    public decimal Debit { get; set; }
    public decimal Credit { get; set; }
    public decimal Balance { get; set; }
}
